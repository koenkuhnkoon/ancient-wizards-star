# The Ancient Wizard's Star — Character & Visual Design Specifications

**Prepared by:** Graphic Designer Agent
**Date:** 2026-02-28
**For:** Pixel artist or image-generation AI use

---

> **Quick Style Reminder for the Artist:**
> All sprites use a bold **2px black outline** (`#1A1A1A`), bright saturated colors, and a top-down view.
> Heads are about 40-50% of the total sprite height — big heads = big personality!
> Think: Brawl Stars energy. Chunky, fun, instantly readable at small sizes.

---

## SECTION 1 — PLAYER CHARACTERS

*All player characters are 48x48 pixels with transparent background.*
*Spritesheet export: idle = 4 frames, walk/run = 6 frames, attack = 4 frames.*

---

### 1.1 Wizard

**Canvas Size:** 48 x 48 px
**Filename prefix:** `player_wizard`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (robe) | Magic Purple | `#9B59B6` |
| Secondary (robe shadow) | Deep Purple | `#6C3483` |
| Accent (star details) | Hero Gold | `#F5C842` |
| Hat | Deep Purple | `#6C3483` |
| Skin | Warm Peach | `#F4C6A0` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The Wizard stands tall with a pointed hat that makes her look taller than any other character. Her long purple robe sweeps down nearly to the bottom of the sprite. From the top-down view you mostly see her hat, shoulders, and the golden star emblem stitched onto her robe chest. She holds a staff in one hand with a tiny glowing orb at the top — the orb glows cyan (`#00E5FF`) like a little nightlight.

**Key Distinguishing Features:**
- Tall, star-tipped pointy hat (deepest purple, with a gold star on the front of the band)
- Long flowing robe — wider at the bottom than the shoulders, creating a triangle silhouette
- Staff held diagonally across the body, orb glowing at top-left of sprite
- Tiny round spectacles on her face (just two small gold circles)
- Gold crescent moon on her belt buckle

**Visual Personality:** Wise, a little mysterious, definitely magical. She looks like she knows a secret.

**Animation Notes:**
- *Idle:* The staff orb pulses from dim to bright cyan every 4 frames. Her hat sways very gently left-right.
- *Walk:* Robe hem shifts slightly left and right as she glides forward. Staff stays mostly still.
- *Attack:* She raises the staff overhead (frames 1-2), a burst of magic orbs radiates out (frame 3), then returns to normal (frame 4).
- *Hurt:* Whole sprite flashes white on frame 1, staff drops slightly.
- *Defeat:* Hat falls off on frame 2, she collapses forward, hat settles on the ground by frame 4.

---

### 1.2 Knight

**Canvas Size:** 48 x 48 px
**Filename prefix:** `player_knight`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (armor) | Steel Blue-Grey | `#7F8C8D` |
| Secondary (armor highlight) | Bright Silver | `#BDC3C7` |
| Accent (cape + plume) | Danger Red | `#E74C3C` |
| Shield face | Bright Silver | `#BDC3C7` |
| Shield emblem | Hero Gold | `#F5C842` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The Knight is the widest player character — broad armored pauldrons (shoulder plates) push out to the very edge of the 48px canvas. From above you see a full helmet with a red plume sticking up, heavy chest plate, and a large round shield on the left arm. The knight is stocky and solid-looking — every pixel says "this person is tough." A short red cape flaps behind the helmet.

**Key Distinguishing Features:**
- Huge round shield with a gold sunburst emblem takes up the left half of the sprite
- Wide shoulder pauldrons with rivets (small dark dots)
- Full-face helmet with red plume (the plume sticks up high — tallest part of the sprite)
- Short red cape visible behind the shoulders
- Sword tip visible at the right edge in idle pose

**Visual Personality:** Brave, strong, reliable. The person you want standing between you and a monster.

**Animation Notes:**
- *Idle:* Barely moves — just a tiny forward-back breathing bob. The plume sways slightly.
- *Walk:* Armor clanks implied by slight left-right shoulder shift. Shield held steady.
- *Attack:* Shield rushes forward (frames 1-2, "Shield Slam"), brief impact flash (frame 3), pulls back (frame 4).
- *Hurt:* Whole sprite recoils backward, a small "clang" crack appears on the shield rim.
- *Defeat:* Armor pieces appear to separate slightly on frame 2, full collapse on frame 3, flat on frame 4.

---

### 1.3 Assassin

**Canvas Size:** 48 x 48 px
**Filename prefix:** `player_assassin`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (outfit) | Very Dark Teal | `#1A3A3A` |
| Secondary (scarf/wrapping) | Shadow Teal | `#2C5F5F` |
| Accent (eyes, blade) | Energy Cyan | `#00E5FF` |
| Belt buckle | Hero Gold | `#F5C842` |
| Skin (eyes only visible) | Warm Peach | `#F4C6A0` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The Assassin is the slimmest character — her silhouette is narrow and slightly crouched forward, like she is always about to spring into action. Almost her entire body is wrapped in dark teal cloth. Only her eyes peek through the face wrap, glowing faintly cyan. Two short blades (daggers) are crossed on her back and visible in the idle pose. She has a gold clasp belt and her wrapping has subtle darker stripe patterns.

**Key Distinguishing Features:**
- Full face wrap with only glowing cyan eyes visible
- Two crossed daggers on back (short blades, silver with cyan edge glow)
- Crouched, forward-leaning posture — lower center of gravity than other characters
- Narrow sprite — lots of empty transparent space on sides at idle
- Subtle teal stripe pattern on the cloth wrapping

**Visual Personality:** Fast, mysterious, dangerous. Blink and she might already be behind you.

**Animation Notes:**
- *Idle:* A very subtle crouch pulse — crouches 2px lower and raises back. Eyes glow slightly brighter on frames 2 and 4.
- *Walk:* Nearly silent, smooth glide. Arms barely move but daggers shift slightly.
- *Run:* Body tilts forward more sharply, daggers trail slightly behind.
- *Attack:* Lunges forward (frame 1-2), both daggers flash out to either side (frame 3 — "Shadow Flash"), snaps back (frame 4).
- *Hurt:* Recoils backward sharply. Eyes go briefly red on frame 1.
- *Defeat:* Falls forward, face-down. Daggers skid to either side.

---

### 1.4 Miner

**Canvas Size:** 48 x 48 px
**Filename prefix:** `player_miner`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (overalls) | Deep Earth Blue | `#2E4A7A` |
| Secondary (shirt) | Warm Orange-Brown | `#C0672A` |
| Accent (helmet, buckles) | Hero Gold | `#F5C842` |
| Skin | Warm Peach | `#F4C6A0` |
| Pickaxe handle | Earth Brown | `#795548` |
| Pickaxe head | Stone Grey | `#8B9DA8` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The Miner is short and stocky — a wide barrel-chested silhouette. He wears blue denim overalls with gold buckles over an orange-brown shirt. His round yellow mining helmet has a tiny headlamp on it (a small white dot that glows). He grips a massive pickaxe that is almost as tall as he is, resting on one shoulder in the idle pose. His face shows a big, friendly grin and rosy cheeks.

**Key Distinguishing Features:**
- Big round yellow mining helmet with a tiny white headlamp dot
- Giant pickaxe resting on right shoulder (handle extends past top of sprite)
- Wide stocky build — almost as wide as he is tall
- Blue denim overalls with visible pocket on the chest
- Rosy red cheeks and squinting happy eyes on his round face

**Visual Personality:** Tough, cheerful, dependable. He looks like he has seen things underground that would scare a wizard, and he still just grins about it.

**Animation Notes:**
- *Idle:* The pickaxe bobs gently as he shifts weight. Headlamp flickers very slightly (dim-bright cycle).
- *Walk:* Wide waddle — hips shift left-right noticeably. Pickaxe swings.
- *Attack:* Raises pickaxe overhead (frame 1), slams it down with both hands (frame 2 — "Rock Blast"), a chunk of ground/rock appears (frame 3), pickaxe lifts back (frame 4).
- *Hurt:* Stumbles backward, helmet tips forward over his eyes.
- *Defeat:* Drops pickaxe (it bounces on frame 2), sits down heavily on frame 3, tips his helmet back sadly on frame 4.

---

### 1.5 Ninja (Player)

**Canvas Size:** 48 x 48 px
**Filename prefix:** `player_ninja`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (gi/outfit) | Deep Navy | `#1B2A4A` |
| Secondary (sash, headband) | Hero Gold | `#F5C842` |
| Accent (shuriken, blade glint) | Star White | `#EAEAEA` |
| Skin | Warm Peach | `#F4C6A0` |
| Headband | Hero Gold | `#F5C842` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The Ninja is energetic and upright — unlike the evil ninjas, this player ninja stands tall and confident. She wears a deep navy gi (ninja outfit) with a bright gold sash belt and gold headband. Her face is fully visible and she has a determined expression with bright eyes. She holds a small glowing shuriken in her right hand that gives off a faint star-sparkle glow. Her braid or ponytail sticks out from the back of the headband.

**Key Distinguishing Features:**
- Face fully visible — distinctive from the masked enemy ninjas
- Bright gold headband (the most visible splash of color from far away)
- Glowing shuriken in one hand (tiny, white, star-shaped with a pale yellow glow)
- Gold sash belt tied at the waist with a knot visible on the right side
- Short ponytail visible behind the head

**Visual Personality:** Fast, cool, confident. She looks ready for anything and she is not even breaking a sweat.

**Animation Notes:**
- *Idle:* Shuriken spins slowly in hand (rotates 90 degrees between frames). Stance is lightly bouncy.
- *Walk:* Light, quiet steps — very little up-down movement, smooth glide.
- *Run:* Body tilts forward aggressively. Arms pump. Much more bounce than walk.
- *Attack:* Wind-up with arm drawn back (frame 1), releases five shurikens in a fan spread (frame 2 — "Star Shuriken"), arm follows through (frame 3), returns (frame 4). The five shurikens are a separate projectile effect.
- *Hurt:* Flips backward slightly, shuriken drops.
- *Defeat:* Does a stumbling flip and lands face-down, gold headband falls off and lands beside her.

---

### 1.6 Robot

**Canvas Size:** 48 x 48 px
**Filename prefix:** `player_robot`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (body panels) | Steel Blue-Grey | `#5D7A8A` |
| Secondary (dark panel edges) | Dark Metal | `#2C3E50` |
| Accent (eye glow, chest core) | Energy Cyan | `#00E5FF` |
| Joints / bolts | Hero Gold | `#F5C842` |
| Antenna tip | Danger Red | `#E74C3C` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The Robot is boxy and mechanical — rectangular body, cylindrical arms, a square head with a visor-slot face. Two glowing cyan eyes peer out from the visor. A circular energy core on his chest pulses cyan. He has a small antenna on top of his head with a red blinking tip. His body panels have visible seams (dark lines) and gold hex-bolt details. His fists are larger than his forearms — chunky and powerful-looking.

**Key Distinguishing Features:**
- Boxy square head with single horizontal cyan visor (two bright dot-eyes inside it)
- Circular chest energy core glowing cyan (`#00E5FF`)
- Small antenna on top-right of head with blinking red tip
- Visible panel seams and gold hex bolts at joints
- Oversized fists compared to forearms

**Visual Personality:** Strong, curious, a little silly. He looks like the most powerful one in the room, but also like he might stop mid-battle to ask what a cloud is.

**Animation Notes:**
- *Idle:* Chest core pulses (dim-bright-dim) every 2 frames. Antenna light blinks. Body barely moves — robots do not breathe!
- *Walk:* Mechanical stomp — clear up-down movement, heavier than other characters. Arms swing stiffly.
- *Run:* Leans forward, steam/exhaust puffs from side vents on frames 2 and 5.
- *Attack:* Raises one fist (frame 1), fist crackles with electricity (frame 2), slams forward releasing electric burst (frame 3 — "Power Surge"), recoils back (frame 4).
- *Hurt:* Sparks fly from the body on frame 1. Visor flickers off then back on.
- *Defeat:* Staggers (frame 1-2), sparks burst from chest core (frame 3), tips forward and falls stiffly like a falling tree (frame 4). Antenna snaps off and rolls away.

---

## SECTION 2 — MONSTERS

*All enemy sprites use heavy dark outlines and danger-leaning color palettes.*
*Enemy colors should feel slightly "wrong" or sickly compared to the clean player colors.*

---

### 2.1 Evil Ninja

**Canvas Size:** 44 x 44 px
**Filename prefix:** `enemy_evil_ninja`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (outfit) | Dark Charcoal | `#2C2C2C` |
| Secondary (wrapping) | Very Dark Red | `#5A1A1A` |
| Accent (eyes, dart tips) | Poison Green | `#A8FF00` |
| Headband | Danger Red | `#E74C3C` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The Evil Ninja looks like a twisted shadow version of the player Ninja. His whole body is wrapped in dark charcoal cloth with dark red accents. His eyes glow a sickly poison green — immediately telling you he is bad news. A bright red headband is the standout detail that makes him easy to spot from a distance (the story even mentions the one with the red headband is the trickiest!). He crouches low, making him look sneaky and hard to hit.

**Key Distinguishing Features:**
- Glowing poison green eyes visible through face wrap (most important distinguishing feature)
- Bright red headband — a pop of red against the dark outfit
- Crouched, sneaking posture — body is lower than the player Ninja
- Small blowdart tube held at the side (short dark tube at hip level)
- Slightly smaller and slimmer than the player Ninja

**Visual Personality:** Sneaky, dangerous, works in a pack. Immediately gives off "do not trust this person" vibes.

**Animation Notes:**
- *Idle:* Crouches even lower on frames 2 and 4 — the sneaking pulse from the art guide. Eyes glow brighter on the crouch.
- *Walk:* Very low to the ground, wide sideways shuffle — no up-down bounce.
- *Attack:* Raises blowdart to mouth (frame 1), fires a dart (frame 2 — dart is a separate tiny projectile), ducks back (frame 3), resets (frame 4).
- *Defeat:* Spins and falls sideways, red headband stays on the ground after the sprite disappears.

---

### 2.2 Sewage Creature

**Canvas Size:** 52 x 44 px
**Filename prefix:** `enemy_sewage_creature`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (body slime) | Sickly Olive Green | `#6B8E23` |
| Secondary (slime drips) | Darker Olive | `#4A6010` |
| Accent (angry eyes) | Sickly Yellow | `#D4E048` |
| Drip highlights | Lime Bright | `#A8FF00` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The Sewage Creature is a wide, low blob of living slime. It is wider than it is tall — a big wobbly mound that jiggles as it moves. Its surface is lumpy and dripping: small drops of darker slime hang off the edges of the body and fall off frame by frame. Two large angry eyes sit in the upper half of the blob — they are yellow-green and have downward-angled "angry eyebrows" drawn in as dark lines on the slime surface. A wide grumpy mouth shows two rows of uneven square teeth.

**Key Distinguishing Features:**
- Extremely wide blob shape — wider than tall
- Constantly dripping slime off the bottom and sides (drip drops visible below the main body)
- Large angry yellow-green eyes with visible "angry brow" lines
- Big grumpy square-tooth grin
- Lumpy, bumpy surface texture (circles and bubble shapes within the body)

**Visual Personality:** Gross, grumpy, and slow. Looks like something that should stay underground. Definitely smells bad.

**Animation Notes:**
- *Idle:* Whole body jiggles slightly left and right. Bubbles appear at the edges on frames 2 and 4 (as described in art guide).
- *Walk:* Leaves a faint slime trail — the sprite slides forward while the body wobbles.
- *Attack:* Body gathers inward (frame 1), launches a glob of slime forward (frame 2 — separate projectile sprite), recoils back (frame 3), settles (frame 4).
- *Defeat:* Body spreads flat and dissolves outward in a slime puddle over frames 1-4.

---

### 2.3 Zombie

**Canvas Size:** 44 x 48 px
**Filename prefix:** `enemy_zombie`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (skin) | Desaturated Blue-Green | `#7AAB8A` |
| Secondary (tattered clothes) | Faded Brown | `#8D6E4A` |
| Accent (eyes, mouth) | Pale Yellow | `#E8E05A` |
| Torn fabric detail | Worn Beige | `#C4A882` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The Zombie is a shuffling former Lumorian farmer — you can still see the tattered remains of a brown work shirt and suspenders. His green-tinted skin sags a little and his arms are extended forward in the classic zombie pose. His expression is confused and dopey, not scary — big pale yellow eyes stare blankly forward. His hair (if he has it) sticks up in random directions. He is slightly taller than he is wide, with a slouched posture that makes him look like he is walking uphill at all times.

**Key Distinguishing Features:**
- Arms extended forward (the most recognizable zombie silhouette feature)
- Tattered farmer clothes — torn suspenders, ripped shirt hem visible
- Confused/dopey facial expression (slightly crossed pale yellow eyes, open mouth)
- Slouched, hunched posture — head pushed forward of the body center
- Visible bread crumb detail on the ground occasionally (a tiny treat for players who read the story)

**Visual Personality:** More sad and silly than scary. He was just a farmer! He is very confused about why he is here.

**Animation Notes:**
- *Idle:* Slow sway left and right, head droops forward on frame 3 (as described in art guide).
- *Walk:* Dragging, shambling shuffle. Feet barely lift off the ground.
- *Attack:* Lurches forward with both arms, grabs at player position (frame 2), stumbles back (frame 3-4). Very slow attack.
- *Defeat:* Falls in pieces — left arm separates, then the whole body collapses. Head rolls a little to the side. (Not gory — cartoonish, like LEGO pieces falling apart.)

---

### 2.4 Land Octopus

**Canvas Size:** 56 x 44 px
**Filename prefix:** `enemy_land_octopus`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (body) | Coral Orange | `#E8723A` |
| Secondary (underside) | Pale Peach-Orange | `#F5B08A` |
| Accent (suckers) | Pale Pink | `#F4A0B8` |
| Eyes | Large, yellow | `#F5E642` |
| Pupil | Dark Slit | `#1A1A1A` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The Land Octopus is the widest enemy sprite — its tentacles spread out to fill nearly the full 56px width. The central body (mantle) sits in the middle-top of the sprite, a rounded orange dome with two enormous yellow eyes with dark slit pupils. Eight tentacles branch out and downward from the body, arranged so 4-5 are visible from the top-down view, each one ending in a row of pale pink suckers. The whole creature is bright coral orange — almost cheerful-looking, which makes it more unsettling.

**Key Distinguishing Features:**
- Extremely wide sprite dominated by sprawling tentacles
- Central dome body with two huge yellow eyes (each eye is about 8px wide)
- Visible pink sucker dots along each tentacle underside
- Some tentacles raised up in the attack-ready position even in idle
- Slightly translucent look to the skin (slightly lighter color in the center of the body, darker at edges)

**Visual Personality:** Creepily cheerful-looking, bizarrely graceful for something walking on tentacles. Very ticklish, apparently.

**Animation Notes:**
- *Idle:* One or two tentacles wave slowly on frames 2 and 4 (as described in art guide). Eyes blink slowly.
- *Walk:* Tentacles ripple in sequence as it crawls forward. Surprisingly smooth motion.
- *Attack:* Two tentacles sweep in a horizontal arc in front of the body — like two spinning arms. The "spin" attack covers a wide arc.
- *Defeat:* Tentacles all curl inward (frames 1-2), body shrinks (frame 3), bursts into small orange pieces (frame 4).

---

### 2.5 Little Devil

**Canvas Size:** 40 x 44 px
**Filename prefix:** `enemy_little_devil`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (skin) | Bright Red | `#E74C3C` |
| Secondary (shadow) | Darker Red | `#922B21` |
| Accent (eyes, flames) | Bright Orange | `#F39C12` |
| Horns | Dark Maroon | `#6B1A1A` |
| Wings | Translucent Dark Red | `#C0392B` |
| Tail tip | Bright Orange | `#F39C12` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The Little Devil is tiny and round — a bright red ball of mischief. Its body is mostly head, with short stubby arms and legs. Two small dark maroon horns poke out of the top of its head. Two large eyes are filled with orange flame-light, giving it a mischievous glowing look. It has two bat-like wings spread to the sides (they keep it hovering just off the ground) and a thin tail with an orange diamond-tip that flicks around. The overall shape from above is like a small oval with wings.

**Key Distinguishing Features:**
- Tiny size compared to all other enemies (the smallest!)
- Bright saturated red skin — the most intensely red thing on screen
- Glowing orange flame-eyes (not just round — slightly flame-shaped, like tiny fire reflections)
- Small bat wings spread out wide relative to body size
- Thin curling tail with orange diamond-tip visible behind the body

**Visual Personality:** Mean, hyper, giggly. Like a toddler who figured out fireballs. Extremely annoying to fight because it never stops moving.

**Animation Notes:**
- *Idle:* Wings flutter rapidly on frames 2 and 4 (as described in art guide). Tail flicks randomly.
- *Walk (fly):* Bobs up and down slightly while moving forward. Wings stay spread.
- *Attack:* Winds up arm (frame 1), throws tiny fireball (frame 2 — round orange projectile), covers face and giggles (frame 3 — implied), resets (frame 4).
- *Hurt:* Puffs up and goes momentarily orange all over on frame 1 — like an inflated angry frog.
- *Defeat:* Spins and gets smaller each frame until it blinks out with a tiny "pop" sparkle.

---

### 2.6 Skeleton

**Canvas Size:** 44 x 48 px
**Filename prefix:** `enemy_skeleton`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (bones) | Off-White Bone | `#E8DCC8` |
| Secondary (bone shadow) | Warm Tan | `#C4A882` |
| Accent (eye glow) | Pale Pale Blue | `#A8D8EA` |
| Rusty sword | Rust Orange-Brown | `#9E4A1A` |
| Cracked shield | Stone Grey | `#8B9DA8` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The Skeleton is tall and thin for a 44x48 sprite — its narrow ribcage and long limbs make it look lanky. Visible ribs are drawn on the chest as horizontal curved lines. The skull has classic large hollow eye sockets with faint blue glow inside, and a wide grinning jaw. The skeleton carries a rusted, chipped sword and a cracked round shield — both props look ancient and poorly maintained. From the top-down view you see the skull prominently, with ribcage visible below and the sword arm extending to one side.

**Key Distinguishing Features:**
- Tall and thin silhouette — the most vertically-oriented enemy sprite
- Visible ribs on the chest (4-5 horizontal bone lines)
- Large hollow eye sockets with faint blue glow
- Rusty chipped sword (not shiny! This sword has seen better centuries)
- Cracked round shield with chunks missing at the edges
- Jaw is slightly open — classic grin, not menacing

**Visual Personality:** Ancient, creaky, vaguely threatening but mostly just old and stubborn. Has been doing this for centuries and is frankly a bit bored about it.

**Animation Notes:**
- *Idle:* Jaw chatters on frames 3 and 4 (as described in art guide). Sword hand sways slightly.
- *Walk:* Clanky, slightly lurching walk. Bones rattle — visually implied by very slight head-bob.
- *Attack:* Raises sword overhead (frame 1), swings down (frame 2 — sword arc effect), recoils (frame 3), resets (frame 4).
- *Hurt:* One bone (arm or rib) pops loose and bounces away for just 1 frame, then snaps back.
- *Defeat:* Head falls off and rolls away (frame 2), body collapses into a pile of bones (frame 3-4). The bones scatter outward slightly before fading.

---

### 2.7 Poisonous Mushroom

**Canvas Size:** 40 x 40 px
**Filename prefix:** `enemy_poisonous_mushroom`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (cap top) | Bright Red-Purple | `#C0392B` mixed with `#9B59B6` — use `#A93560` |
| Secondary (cap spots) | Pale Lavender | `#D7BDE2` |
| Accent (spore puffs) | Poison Purple | `#9B59B6` |
| Stem | Pale Cream | `#FAF0DC` |
| Eyes (grumpy) | Dark Brown | `#3E1F00` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The Poisonous Mushroom is almost perfectly round — a big circular cap on top of a short stubby cream-colored stem. The cap is a rich red-purple color with pale lavender spots (like classic cartoon mushroom spots but purple-tinted). The stem has two tiny stubby legs and two small arm-stubs. The mushroom's "face" is on the front of the cap (facing the player) — two small dark grumpy eyes under arched angry brows, and a small downward frown. It looks permanently unimpressed and slightly annoyed at everything.

**Key Distinguishing Features:**
- Nearly perfect circle silhouette for the cap (dominant shape)
- Purple-tinged red cap with pale round spots
- Tiny stubby legs at the bottom of the stem — it looks almost too small to walk
- Grumpy downward-frown face (no teeth — just a simple curved frown line)
- Faint purple spore wisps floating around it in idle (tiny purple dots floating upward)

**Visual Personality:** Grumpy and round. Looks like it woke up on the wrong side of the forest floor. Zero interest in being friendly.

**Animation Notes:**
- *Idle:* Cap bounces up on frame 2, settles on frame 4 (as described in art guide). Purple spore dots float up from the cap edges.
- *Walk:* Hops forward in small jumps — it does not walk, it bounces. Fun and slightly silly.
- *Attack:* Inflates slightly (frame 1), releases a cloud of purple spores in a ring (frame 2 — the poison cloud effect), deflates (frame 3), resets (frame 4).
- *Hurt:* Cap tilts to one side, face looks shocked (eyes go wide) on frame 1.
- *Defeat:* Pops like a balloon over frames 1-3, leaves a small purple spore cloud that fades on frame 4.

---

### 2.8 Stonehead Turtle

**Canvas Size:** 56 x 48 px
**Filename prefix:** `enemy_stonehead_turtle`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (shell) | Stone Grey | `#8B9DA8` |
| Secondary (shell dark patches) | Dark Stone | `#5A6B74` |
| Accent (shell cracks + glow) | Shard Teal | `#1ABC9C` |
| Head skin | Mossy Green | `#6B8E5A` |
| Shell edge trim | Earth Brown | `#795548` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The Stonehead Turtle's shell is literally the whole sprite — a massive dome of grey rock fills nearly 70% of the 56x48 canvas. The shell is not smooth: it is covered in natural stone-like hexagonal plates with dark gaps between them, and thin cracks that glow faintly teal (this is magical stone, after all). A small, ancient-looking mossy green head pokes out from the front of the shell. The head has small tired eyes and a determined closed-mouth expression. Four stubby legs barely peek out from under the shell edges.

**Key Distinguishing Features:**
- Massive rocky shell dominates the entire sprite (most of the visible area IS the shell)
- Hexagonal plate pattern on shell surface
- Thin glowing teal cracks in the shell — ancient magical stone
- Tiny ancient green head compared to the huge shell body
- Barely-visible stubby legs at shell edges

**Visual Personality:** Ancient, slow, nearly indestructible. Has seen 500 years of history and is mildly inconvenienced by you trying to defeat it.

**Animation Notes:**
- *Idle:* Head retreats into shell on frame 3, peeks back out on frame 4 (as described in art guide). Shell glowing cracks pulse faintly.
- *Walk:* Very slow trudge. Shell barely moves up-down. Legs move in the background.
- *Attack:* Head extends far forward and bites (frame 2). Then curls into shell and rolls: the sprite shifts to a full circle (shell curled up) and drifts forward — the "roll downhill" move.
- *Hurt:* Head instantly pulls fully inside shell. Only shell remains visible. Cracks on shell flash brighter on frame 1.
- *Defeat:* Shell cracks widen (frames 1-2), shell breaks into three large pieces (frame 3), pieces fade (frame 4). No gore — just stone chunks.

---

## SECTION 3 — BOSSES

*Boss sprites are larger and more detailed. They should feel genuinely impressive.*

---

### 3.1 Grimrak the Stone Golem (Helper-Boss 1)

**Canvas Size:** 80 x 80 px
**Filename prefix:** `boss_grimrak`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (stone body) | Dark Stone Grey | `#5A6B74` |
| Secondary (stone highlights) | Mid Stone Grey | `#8B9DA8` |
| Accent (chest crack glow) | Hero Gold | `#F5C842` |
| Eye glow | Danger Red | `#E74C3C` |
| Stolen shard (chest) | Shard Teal | `#1ABC9C` |
| Moss accent | Grass Green | `#4CAF50` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
Grimrak is a towering pile of rocks shaped into a golem. His body is made of large stacked boulder-chunks: wide flat feet, enormous square legs, a barrel-wide torso, and massive slab arms that end in boulder-fists the size of the player's entire body. His head is a rough rectangular boulder with two deep-set glowing red eye pits and a jagged crack for a mouth. The most important detail: in the center of his chest is a visible glowing crack filled with teal-and-gold light — this is where the shard of the Ancient Wizard's Star was jammed to bring him to life. Patches of green moss grow in the gaps between his stone segments.

**Key Distinguishing Features:**
- Enormous scale — he should fill most of the 80x80 canvas
- Glowing chest crack with shard teal and gold light (the weak point players must hit)
- Boulder-chunk segments with visible gaps between them (he is assembled, not solid)
- Red glowing sunken eye sockets (narrow, angry slits)
- Moss growing in the joint gaps (green patches at shoulders, elbows, and waist)
- Boulder-fists larger than his head

**Visual Personality:** Unstoppable. Ancient. A wall with arms. He does not look smart, but he does not need to be.

**Animation Notes:**
- *Idle:* Ground vibration implied by stone dust particles falling from his body. Chest crack pulses teal-gold slowly.
- *Move:* Each step causes a small shake in the sprite. Arms swing heavily.
- *Shockwave Attack:* Raises both fists overhead (frame 1), slams the ground with massive impact (frame 2 — shockwave ring effect radiates out), raises again covered in dust (frame 3), resets (frame 4).
- *Boulder Throw:* Breaks a chunk off his own shoulder (frame 1), winds up (frame 2), hurls it (frame 3 — large boulder projectile), gap in shoulder remains for 1-2 frames (frame 4).
- *Hurt:* Stone chips fly off. Chest crack glows bright white for a moment.
- *Defeat:* Chest crack bursts with gold-teal light (frame 1-2), body segments fall apart inward (frame 3-4), pile of rubble remains for a moment, then shard floats upward.

---

### 3.2 Zara the Storm Witch (Helper-Boss 2)

**Canvas Size:** 64 x 64 px
**Filename prefix:** `boss_zara`

**Color Breakdown (Enemy Phase — while fighting the player):**
| Role | Color | Hex |
|------|-------|-----|
| Primary (robes — enemy phase) | Thunderstorm Blue-Grey | `#5D6D7E` |
| Secondary (robe shadow) | Dark Blue-Grey | `#2E4057` |
| Accent (lightning, eyes) | Bright Yellow | `#F5C842` |
| Storm cloud accent | Cloud White | `#FAFAFA` |
| Staff crystal | Energy Cyan | `#00E5FF` |
| Outline | Near-Black | `#1A1A1A` |

**Color Breakdown (Ally Phase — after being defeated):**
| Role | Color | Hex |
|------|-------|-----|
| Primary (robes — ally phase) | Sky Blue | `#5BC8F5` |
| Accent (magic, eyes) | Warm Gold | `#F5C842` |
| Staff crystal | Soft Lavender | `#BB8FCE` |

**Visual Description:**
Zara is a tall, dramatically-cloaked weather witch. In her enemy phase, her robes are stormy blue-grey and billow outward as if blown by a constant wind — the robe edges are uneven and tattered like storm clouds. Her face has sharp features (angular jaw, sharp brow) and glowing yellow lightning-crackle eyes. Her staff is topped with a swirling cyan vortex of energy. She floats slightly above the ground — no feet are visible, the robe fades into a misty cloud base. In her ally phase after defeat, her robe lightens to sky blue, her eyes become warm gold instead of lightning-white, and her expression softens.

**Key Distinguishing Features:**
- Floating posture — no feet, robe fades to mist at the bottom
- Dramatically billowing storm-cloud robe edges (uneven, cloud-shaped hem)
- Sharp, angular face with intensity (enemy) or warm softness (ally) — two different expressions
- Staff with swirling energy vortex at the top (changes from cyan to lavender after defeat)
- Small storm-cloud wisps floating around her in idle

**Visual Personality (Enemy):** Powerful, weather-witch intensity. She is not evil, just wrongly convinced. The anger in her eyes has hurt behind it.
**Visual Personality (Ally):** Relieved, warm, ashamed-but-recovering. A little like someone who just realized they were wrong and wants to make it right.

**Animation Notes:**
- *Idle (Enemy):* Robe billows, lightning sparks on her eyes on frames 2 and 4. Small cloud wisps orbit slowly.
- *Move:* Glides forward smoothly — no leg animation since she floats.
- *Lightning Storm Attack:* Raises staff (frame 1), sky above darkens slightly (frame 2), multiple lightning bolts strike the ground in a spread (frame 3 — lightning bolt effects), lowers staff (frame 4-5), recovers (frame 6).
- *Whirlwind Attack:* Spins in place (frames 1-2), a whirlwind ring radiates outward (frame 3-4).
- *Defeat Transition:* Lightning eyes flicker (frames 1-2), robe color shifts from grey to blue (frame 3-4), she floats lower to near-ground level (frame 5-6), expression changes, she looks down in shame.
- *Idle (Ally):* Softer robe billow, warm golden sparkles instead of lightning.

---

### 3.3 Voltrak the Shockblade Eel — Final Boss

**Canvas Size:** 128 x 64 px
**Filename prefix:** `boss_ninja_land_eel`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (eel body scales) | Electric Blue | `#1A3A8A` |
| Secondary (underbelly) | Lighter Blue | `#3A6ABF` |
| Accent (lightning markings) | Bright Yellow | `#F5C842` |
| Sword "Thunderfang" | Dark Steel | `#5D6D7E` |
| Sword lightning edge | Bright Yellow-White | `#FFF59D` |
| Eye (alive) | Slit-pupil gold | `#F5C842` |
| Ninja mask | Near-Black | `#1A1A1A` |
| Ninja mask trim | Danger Red | `#E74C3C` |
| Neck star-mark (weak point) | Shard Teal glow | `#1ABC9C` |
| Lightning crackle effects | Electric White-Yellow | `#FFFDE7` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
Voltrak is the most dramatic sprite in the game — a massive horizontal eel body in a flowing S-curve that fills the 128x64 canvas from left to right. His scales are deep electric blue with jagged bright yellow lightning stripe markings running along the length of his body. His head occupies the right quarter of the sprite: a long eel face wearing a black ninja mask (tied around the snout) with thin red trim. His eye is a large slit-pupil gold iris. He stands upright on his tail end (which curves under and to the left side of the canvas) and holds the sword Thunderfang in one arm — yes, he has arms! Two short powerful arms emerge from just behind the head, scaled and clawed. The left arm grips Thunderfang. The sword crackles constantly with yellow-white electricity along its edge.

The most important detail for gameplay: on his neck (just behind the jaw, center-left of the sprite) is a faintly glowing teal circle — the star-mark where the stolen shard of the Ancient Wizard's Star sits inside him. This is his weak point.

**Key Distinguishing Features:**
- Massive S-curve body filling the full 128px width
- Deep blue scales with bright jagged yellow lightning stripe patterns
- Ninja mask on his snout (tied behind the head, black with thin red trim)
- Thunderfang sword crackling with electricity in one clawed arm
- Visible teal glow on the neck (the weak point — players must learn to aim for it)
- The sword is large — about 1/4 of the sprite width

**Phase 1 vs Phase 2 Visual Changes:**
- Phase 1 (full health): Body is mostly electric blue. Lightning markings are yellow. He stays low, ground-level.
- Phase 2 (half health): Body brightens to brighter blue, lightning markings become white-hot (`#FFFFFF`). He rears up taller in the sprite. The neck teal glow pulses much faster and brighter.

**Visual Personality:** Genuinely terrifying but also somehow sad when you know the backstory. He was once just a curious little eel who found a door he should not have opened. Now he crackles with stolen power and ancient rage.

**Animation Notes:**
- *Idle:* Body undulates in an S-wave from head to tail, electric sparks appear on frames 3 and 6 (as described in art guide). Thunderfang edge crackles constantly.
- *Move:* S-wave speeds up, body slides sideways with surprising smoothness.
- *Sword Attack (Thunderfang Slash):* Raises sword (frame 1), sword charges — lightning crackles along full blade length (frame 2), horizontal slash arc with electric bolt extending from the swing (frames 3-4), recoils (frame 5), resets (frame 6). Electric bolt is a separate wide effect sprite.
- *Electric Burst (Phase 2):* Body glows white-hot (frame 1), ring of electricity explodes outward from body center (frames 2-3 — electric ring effect), fades (frame 4).
- *Hurt:* Whole sprite flashes white, the teal neck mark glows very brightly for 1 frame.
- *Defeat:* Spasms with sparks all over body (frames 1-4), body begins to dissolve into light particles (frame 5-6), bright flash of gold-teal fills the canvas (frame 7), empty canvas with just the floating shard (frame 8).

---

## SECTION 4 — WORLD TILES AND ENVIRONMENT

*All world tiles are 32 x 32 px and tile seamlessly edge-to-edge.*

---

### 4.1 Grass Tile

**Canvas Size:** 32 x 32 px
**Filename:** `tile_grass.png`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (main grass) | Grass Green | `#4CAF50` |
| Secondary (dark patches) | Deeper Green | `#388E3C` |
| Accent (light patches) | Light Green | `#66BB6A` |
| Blade details | Bright Green | `#81C784` |

**Visual Description:**
A top-down view of lush green grass. The base is solid grass green, broken up by subtle darker and lighter patches to avoid a flat look. Small V-shaped grass blade marks (3-4 per tile) are scattered across the surface in slightly lighter green. The edges of the tile blend smoothly — no hard lines at tile borders. One or two tiny flower dots (white with yellow centers, about 2px each) can appear rarely for visual interest.

**Animation Notes:** Static tile — no animation needed. However, a rare second tile variation (`tile_grass_alt.png`) can be made with slightly different blade placement for visual variety.

---

### 4.2 Stone/Dirt Path Tile

**Canvas Size:** 32 x 32 px
**Filename:** `tile_dirt.png`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (dirt base) | Deep Earth | `#7B5E3A` |
| Secondary (stone patches) | Stone Grey | `#8B9DA8` |
| Accent (worn grooves) | Dark Earth | `#5A3E20` |
| Pebble dots | Tan | `#C4A882` |

**Visual Description:**
A worn dirt path tile with scattered small stones embedded in it. The base is a warm earthy brown. Irregular darker groove lines run across the surface suggesting cart-wheel tracks or foot-worn paths. Small rounded pebbles (stone grey dots, 2-3px each) are scattered across the tile. Some small stone-grey patches suggest where dirt has worn away to reveal rock underneath. This tile should look used and traveled.

**Animation Notes:** Static tile.

---

### 4.3 Water Tile

**Canvas Size:** 32 x 32 px
**Filename:** `tile_water.png` (4-frame animated spritesheet: 128 x 32 px)

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (deep water) | Deep Blue | `#1565C0` |
| Secondary (surface) | Sky Blue | `#5BC8F5` |
| Accent (ripple highlights) | Bright Light Blue | `#81D4FA` |
| Sparkle | Cloud White | `#FAFAFA` |

**Visual Description:**
Top-down water with gentle ripple animation. The base is a deep blue. Lighter blue oval/ellipse ripple shapes drift across the surface. Small white sparkle dots appear at ripple peaks. The tile should feel calm and slightly magical.

**Animation Notes:**
- Frame 1: Ripple ovals in one position, sparkles at top-left.
- Frame 2: Ripples shift slightly right and upward, sparkles move.
- Frame 3: Ripples at furthest position from start.
- Frame 4: Ripples return toward start. Creates seamless 4-frame loop.

---

### 4.4 Magic Glowing Tile

**Canvas Size:** 32 x 32 px
**Filename:** `tile_magic_glow.png`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (stone base) | Stone Grey | `#8B9DA8` |
| Secondary (etched lines) | Dark Stone | `#5A6B74` |
| Accent (glow fill) | Magic Purple | `#9B59B6` |
| Glow edge | Energy Cyan | `#00E5FF` |

**Visual Description:**
A stone tile with magical runes carved into it that glow with purple-cyan light. The base stone is grey with darker stone seams. Carved into the surface are simple angular rune symbols — abstract lines and dots arranged in geometric patterns. The carved grooves glow from within with magic purple, edged with a thin cyan highlight. This tile is used near portal areas and ancient magical sites. It should feel old, important, and a little spooky.

**Animation Notes:** Gentle pulsing animation — glow goes from 70% brightness to full brightness and back. 4-frame cycle. The rune pattern itself does not move, only the glow intensity changes.

---

### 4.5 Wall/Rock Tile

**Canvas Size:** 32 x 32 px
**Filename:** `tile_wall.png`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (main stone) | Stone Grey | `#8B9DA8` |
| Secondary (mortar gaps) | Dark Stone | `#5A6B74` |
| Accent (top highlight) | Light Stone | `#AABDC7` |
| Shadow bottom | Very Dark Stone | `#3A4A52` |

**Visual Description:**
A solid stone wall tile viewed from above, showing the top face of the wall. Brick/stone blocks are visible separated by darker mortar lines arranged in a brick pattern (horizontal rows with alternating offsets). The top-left of each block gets a lighter highlight, the bottom-right gets a shadow — this simple shading gives the wall a sense of depth even from the top-down view. This tile is impassable.

**Animation Notes:** Static tile.

---

### 4.6 Tree Top Tile

**Canvas Size:** 32 x 32 px
**Filename:** `tile_tree_top.png`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (foliage) | Grass Green | `#4CAF50` |
| Secondary (shadow side) | Deeper Green | `#2E7D32` |
| Accent (highlight) | Light Green | `#81C784` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The round, lollipop-style treetop viewed from directly above. The foliage fills most of the 32x32 tile as an irregular rounded circle (not a perfect circle — slightly lumpy edges for organic feel). The right-and-bottom side is shaded deeper green, the left-and-top is lighter green, suggesting light coming from the upper-left. A few small circular "bubble" shapes within the main mass suggest individual leaf clusters. Bold black outline around the whole foliage shape.

**Animation Notes:** Static tile.

---

### 4.7 Tree Trunk Tile

**Canvas Size:** 32 x 32 px
**Filename:** `tile_tree_trunk.png`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (trunk) | Earth Brown | `#795548` |
| Secondary (shadow) | Dark Brown | `#4E342E` |
| Accent (highlight line) | Light Brown | `#A1887F` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The tree trunk viewed from above — a small oval or rounded rectangle centered in the tile. The trunk takes up about 12x12 pixels of the 32x32 space, leaving transparent edges so the grass tile below shows through. The trunk has a simple vertical highlight line suggesting a rounded cylinder shape. This tile is placed directly below the tree top tile.

**Animation Notes:** Static tile.

---

### 4.8 Wooden Bridge Tile

**Canvas Size:** 32 x 32 px
**Filename:** `tile_bridge.png`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (planks) | Light Wood | `#C4A063` |
| Secondary (plank gaps) | Dark Wood | `#795548` |
| Accent (nails/pegs) | Dark Metal | `#2C3E50` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
Old wooden bridge planks viewed from above. Three or four horizontal plank boards run across the tile, each separated by a thin dark gap. Each plank has subtle wood grain lines (horizontal lighter streaks) to show the wood texture. Small dark nail dots appear at the corners of each plank. The overall color is warm light wood. Bridge tiles placed next to water tiles let players walk over rivers.

**Animation Notes:** Static tile.

---

### 4.9 Respawn Point Marker

**Canvas Size:** 32 x 32 px
**Filename:** `world_respawn_point.png` (4-frame animated spritesheet: 128 x 32 px)

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (glow circle) | Shard Teal | `#1ABC9C` |
| Secondary (inner core) | Energy Cyan | `#00E5FF` |
| Outer fade | Transparent Teal | `#1ABC9C` at 30% opacity |
| Center icon | Cloud White | `#FAFAFA` |

**Visual Description:**
A friendly glowing circle on the ground marking a safe respawn spot. A central small star or plus-sign in white sits in the middle. Around it radiates a teal-cyan glow circle that fills most of the tile. The glow fades toward the edges (transparency). The overall effect should feel warm and safe — this is a good place to come back to!

**Animation Notes:**
- Gentle pulse: glow expands and contracts.
- Frame 1: Glow at normal size.
- Frame 2: Glow slightly larger and brighter.
- Frame 3: Glow at maximum size (about 2px beyond normal).
- Frame 4: Glow shrinks back to Frame 1 size.
- Loop creates a calm "breathing" feel.

---

### 4.10 Ancient Dimensional Portal Gate (Multi-tile)

**Overall Assembled Size:** 3 tiles wide x 4 tiles tall = 96 x 128 px
**Single tile size:** 32 x 32 px each
**Filename:** `world_portal_gate.png` (full assembled sprite, 8-frame swirl: 1024 x 128 px)

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Stone frame | Dark Stone Grey | `#5A6B74` |
| Frame accent | Hero Gold | `#F5C842` |
| Portal vortex (outer) | Magic Purple | `#9B59B6` |
| Portal vortex (middle) | Energy Cyan | `#00E5FF` |
| Portal vortex (inner core) | Cloud White | `#FAFAFA` |
| Rune carvings | Hero Gold glow | `#F5C842` |
| Cracked sections | Danger Red glow | `#E74C3C` |

**Tile Layout (3 columns x 4 rows):**
```
[ LEFT PILLAR TOP ]  [ ARCH TOP CENTER ]   [ RIGHT PILLAR TOP ]
[ LEFT PILLAR MID ]  [ PORTAL SWIRL TOP ]  [ RIGHT PILLAR MID ]
[ LEFT PILLAR BOT ]  [ PORTAL SWIRL BOT ]  [ RIGHT PILLAR BOT ]
[ LEFT BASE      ]   [ CENTER BASE      ]   [ RIGHT BASE      ]
```

**Visual Description:**
The Ancient Dimensional Portal Gate is the biggest set piece in the game. The frame is a grand stone arch — two thick stone pillars rise on the left and right sides, joined by a curved arch at the top. The stone is dark grey with gold rune carvings along the edges. Cracks run across the arch and pillars, glowing faintly red (the damage Voltrak caused). The interior of the arch is filled with a swirling magical vortex — concentric rings of purple and cyan spiral inward toward a white core, like looking into the center of a galaxy. The whole gate radiates magical energy.

**Key Visual Details:**
- Pillars: Dark stone with gold rune lines etched vertically. Red-glowing cracks on both pillars.
- Arch top: Stone keystone in the center with a large gold star carved on it.
- Portal interior: Swirling purple-cyan vortex. The swirl rotates clockwise in animation.
- Base: Wide rectangular stone bases at the bottom of each pillar. Glowing rune circles on the floor in front of the base.

**Animation Notes:**
- 8-frame clockwise rotation of the swirling energy rings inside the arch.
- The outer purple ring moves, the inner cyan ring moves slightly faster (creates depth).
- The white core pulses (dim on frames 2-4-6, bright on frames 1-3-5-7).
- Gold rune carvings on the pillars pulse with a slow glow on every other frame.

---

## SECTION 5 — ITEMS AND PICKUPS

---

### 5.1 Magical Shard

**Canvas Size:** 16 x 16 px
**Filename:** `item_magical_shard.png` (4-frame spin: 64 x 16 px)

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (crystal body) | Shard Teal | `#1ABC9C` |
| Secondary (facet highlight) | Energy Cyan | `#00E5FF` |
| Accent (dark facet) | Deep Teal | `#0E6655` |
| Outline | Near-Black | `#1A1A1A` |
| Sparkle | Cloud White | `#FAFAFA` |

**Visual Description:**
A small faceted crystal gem shape — like a tiny diamond but with 5-6 visible facets. About 10x12px of the 16x16 canvas is used, leaving a small transparent border. The crystal is teal-cyan with different facets shaded lighter and darker to show its 3D shape. A tiny white sparkle dot appears at the top-right of the crystal. This is the most common collectible in the game so it needs to be instantly recognizable.

**Animation Notes:**
- 4-frame slow rotation: the highlight facet shifts from top-right to right to bottom-right to back to top-right as the crystal appears to spin.
- A small sparkle burst appears on frame 1 and frame 3 for extra visual pop.

---

### 5.2 Health Potion

**Canvas Size:** 16 x 16 px
**Filename:** `item_health_potion.png`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (liquid) | Danger Red | `#E74C3C` |
| Secondary (bottle glass) | Light Blue-Glass | `#AEE5F5` |
| Accent (highlight) | Cloud White | `#FAFAFA` |
| Cork/cap | Earth Brown | `#795548` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
A small round-bottomed glass bottle about 10x14px within the 16x16 canvas. The bottle has a round bulging base tapering to a short neck with a brown cork stopper. The glass is transparent light blue-tinted, and inside it the red liquid fills about 80% of the bottle. A small white oval highlight on the upper-left of the bottle shows the glass surface catching light. The red liquid is bright and vivid — unmistakably "health."

---

### 5.3 Energy Potion

**Canvas Size:** 16 x 16 px
**Filename:** `item_energy_potion.png`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (liquid) | Energy Cyan | `#00E5FF` |
| Secondary (bottle glass) | Light Blue-Glass | `#AEE5F5` |
| Accent (highlight) | Cloud White | `#FAFAFA` |
| Cork/cap | Dark Metal | `#2C3E50` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
Identical bottle shape to the health potion, but the liquid inside glows bright cyan and the stopper is a dark metal cap instead of cork (suggesting this is a more technological/magical concoction). The cyan liquid actually glows slightly — a thin bright cyan outline around the liquid area inside the glass. Optional: tiny lightning bolt symbol visible through the glass on the liquid surface.

---

### 5.4 Weapon Pickup Icon (Sword)

**Canvas Size:** 24 x 24 px
**Filename:** `item_sword.png`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Blade | Bright Silver | `#BDC3C7` |
| Blade edge highlight | Cloud White | `#FAFAFA` |
| Guard (crossguard) | Hero Gold | `#F5C842` |
| Handle/grip | Earth Brown | `#795548` |
| Pommel | Hero Gold | `#F5C842` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
A classic straight sword viewed at a 45-degree angle from above (diagonal across the 24x24 canvas — this gives it visual interest compared to a flat vertical sword). The blade runs from bottom-left to top-right. The blade is silver with a thin white highlight line along one edge. The gold crossguard sits in the middle, angled perpendicular to the blade. Below it the brown grip leads to a gold round pommel at the bottom-left corner.

---

### 5.5 Armor Pickup Icon (Shield)

**Canvas Size:** 24 x 24 px
**Filename:** `item_armor_shield.png`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (shield face) | Bright Silver | `#BDC3C7` |
| Secondary (shield border) | Hero Gold | `#F5C842` |
| Emblem | Danger Red | `#E74C3C` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
A round shield viewed from slight angle (not perfectly flat — a little 3D). The face is silver with a gold outer ring border. In the center is a small red diamond or star emblem. The top of the shield curves outward slightly. A thin dark shadow line on the right side and bottom suggests depth. The overall shape is a slightly rounded circle, about 20x20px of the 24x24 canvas.

---

## SECTION 6 — NPC DESIGNS

*NPC sprites are 44x44px for villagers and shopkeeper, 48x48px for companions.*

---

### 6.1 Friendly Villager

**Canvas Size:** 44 x 44 px
**Filename prefix:** `npc_villager`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (tunic) | Warm Amber | `#E67E22` |
| Secondary (undershirt) | Cream | `#FAF0DC` |
| Accent (belt, trim) | Earth Brown | `#795548` |
| Skin | Warm Peach | `#F4C6A0` |
| Hair | Medium Brown | `#7B4F2E` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
A cheerful-looking Lumorian villager dressed in everyday warm-colored clothes. She (or he — this is the generic villager) wears a simple amber-orange tunic with a cream undershirt visible at the collar and cuffs. A brown leather belt cinches the waist. Her face has a round, friendly shape with rosy cheeks and a small smile. Her hair is medium brown and slightly messy — she has been busy. She might be carrying a small basket or bundle of vegetables (optional accessory prop).

**Key Distinguishing Features:**
- Warm amber tunic (immediately warm and friendly-colored)
- Round, friendly face with smile and rosy cheeks
- No armor, no weapons — this person is clearly not a fighter
- Optional: small basket or farming tool in one hand

**Animation Notes:**
- *Idle:* Gentle side-to-side sway, occasional look left or right (head turns slightly on frame 3).
- *Walk:* Simple 4-frame walk cycle with gentle arm swing.

---

### 6.2 Shopkeeper

**Canvas Size:** 44 x 44 px
**Filename prefix:** `npc_shopkeeper`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (apron) | Cream-White | `#FAF0DC` |
| Secondary (shirt under apron) | Warm Purple | `#BB8FCE` |
| Accent (apron pocket) | Hero Gold | `#F5C842` |
| Hat | Tall Merchant Brown | `#795548` |
| Skin | Warm Peach | `#F4C6A0` |
| Mustache/hair | Dark Brown | `#4E342E` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
A jolly shopkeeper who is clearly very proud of his merchandise. He wears a cream apron over a purple shirt, and a tall flat-topped merchant's hat (like a stovepipe hat, but shorter). He has a curly dark mustache and small twinkling eyes. His apron has a visible pocket from which a small gold coin peeks. He stands with a friendly open posture — hands slightly raised as if perpetually about to present his wares. He looks like someone who genuinely enjoys selling things, especially to heroes.

**Key Distinguishing Features:**
- Tall flat-topped merchant's hat (the most distinctive silhouette element)
- Cream apron with a visible coin/item peeking from the pocket
- Curly mustache
- Purple shirt visible at collar and sleeves

**Animation Notes:**
- *Idle:* Hands wave slightly, as if beckoning the player. Head bobs slightly. Very energetic for a shopkeeper.

---

### 6.3 Player Companion 1 — The Valiant Companion Knight

**Canvas Size:** 48 x 48 px
**Filename prefix:** `npc_companion_knight`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (armor) | Warm Brass | `#B7860B` |
| Secondary (armor shadow) | Dark Brass | `#7B5A08` |
| Accent (cape, plume) | Sky Blue | `#5BC8F5` |
| Shield face | Warm Brass | `#B7860B` |
| Shield emblem | Shard Teal star | `#1ABC9C` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
The Companion Knight is clearly a hero — her armor is warm gleaming brass-gold rather than plain grey steel, immediately setting her apart from regular enemies and feel of a companion who has been on many adventures. She wears a full helmet with a sky-blue plume that matches the hopeful colors of Lumoria. Her shield bears a teal star emblem — a reference to the Ancient Wizard's Star she fights to protect. She stands tall and confident, one fist raised slightly as if rallying the player. Her expression (visible through the open face visor) is determined and warm.

**Key Distinguishing Features:**
- Warm brass-gold armor (not silver — this immediately distinguishes her as an ally, not an enemy)
- Sky-blue plume on the helmet (ties to the hopeful color palette)
- Teal star emblem on shield (callbacks to the quest's mission)
- Open visor shows her determined face
- Slightly smaller scale than Grimrak's intimidating bulk — but clearly ready

**Visual Personality:** Brave, reliable, and enthusiastic. The kind of companion who runs in first and worries about the plan later.

**Animation Notes:**
- *Idle:* Shield held steady, sword taps lightly against it on frame 3 (a confident "let's go" tap).
- *Walk:* Confident stride, brass armor gleams on frame 2 (highlight shifts).
- *Attack:* Charges forward with shield raised (frames 1-2), slam impact (frame 3), recovers (frame 4).

---

### 6.4 Player Companion 2 — Luma the Apprentice Wizard

**Canvas Size:** 48 x 48 px
**Filename prefix:** `npc_companion_wizard`

**Color Breakdown:**
| Role | Color | Hex |
|------|-------|-----|
| Primary (robes) | Sky Blue | `#5BC8F5` |
| Secondary (robe shadow) | Medium Blue | `#3A8ABF` |
| Accent (star details) | Hero Gold | `#F5C842` |
| Hat | Deep Sky Blue | `#1565C0` |
| Skin | Warm Peach | `#F4C6A0` |
| Staff orb | Shard Teal glow | `#1ABC9C` |
| Outline | Near-Black | `#1A1A1A` |

**Visual Description:**
Luma is a young apprentice wizard — clearly excited to be on a real adventure for the first time. Her robes are sky-blue (lighter and more hopeful than the player Wizard's purple, suggesting she is still learning). Her pointed hat is deep blue and slightly too big for her — it tips a little to one side, giving her an endearing, slightly goofy look. Her staff is slimmer than the player Wizard's and the orb at the top glows warm teal — she has been practicing! She looks eager and enthusiastic, wide-eyed and ready.

**Key Distinguishing Features:**
- Sky-blue robes (lighter and friendlier tone than the player Wizard's purple)
- Hat slightly too big and tipped to one side — she grew into it!
- Slim apprentice staff with teal glowing orb
- Wide, enthusiastic eyes visible on her face
- A star-shaped brooch on her collar (shows she takes wizardry very seriously)

**Visual Personality:** Eager, enthusiastic, a little nervous but completely committed. She believes in the player completely and is NOT going to let them down.

**Animation Notes:**
- *Idle:* Staff orb bobs slightly up and down. She shifts weight from foot to foot — can't quite stand still.
- *Walk:* Light, hurrying steps — she walks slightly faster than necessary.
- *Attack:* Concentrates (frame 1 — closes eyes), fires a teal magic bolt forward (frame 2), stumbles back slightly from the recoil (frame 3 — this is an apprentice after all!), steadies herself (frame 4).

---

## APPENDIX — QUICK REFERENCE COLOR PALETTE

For all artists working on this project:

| Color Name | Hex Code | Primary Use |
|------------|----------|-------------|
| Grass Green | `#4CAF50` | Ground tiles, foliage |
| Deeper Green | `#388E3C` | Grass shadow, moss |
| Sky Blue | `#5BC8F5` | Sky, water, Luma's robes |
| Deep Blue | `#1565C0` | Deep water, night elements |
| Magic Purple | `#9B59B6` | Wizard magic, portal vortex |
| Dark Purple | `#6C3483` | Wizard robe shadow |
| Hero Gold | `#F5C842` | Accents, UI, stars, companion armor |
| Danger Red | `#E74C3C` | Enemies, health bar, evil elements |
| Dark Red | `#922B21` | Enemy shadow |
| Energy Cyan | `#00E5FF` | Energy, robot core, magic bolts |
| Shard Teal | `#1ABC9C` | Collectible shards, star marks |
| Earth Brown | `#795548` | Paths, wood, handles |
| Deep Earth | `#7B5E3A` | Dirt paths, deep wood |
| Stone Grey | `#8B9DA8` | Walls, rocks, turtle shells |
| Dark Stone | `#5A6B74` | Wall shadow, Grimrak's body |
| Poison Green | `#A8FF00` | Evil ninja eyes, poisonous effects |
| Outline Black | `#1A1A1A` | ALL sprite outlines (never pure #000000) |
| Cloud White | `#FAFAFA` | Sparkles, highlights, UI text |
| Warm Peach | `#F4C6A0` | Character skin |
| Electric Blue | `#1A3A8A` | Voltrak's body |

---

*Character designs created by the Graphic Designer Agent for The Ancient Wizard's Star.*
*Review with Koen and his dad before sending to pixel artist!*
*Remember: these designs should make an 8-year-old excited to see them come to life!*
