# Art Brief — Character Idle & Walk Animations

**Game:** The Ancient Wizard's Star (Python/Pygame, top-down RPG)
**Style:** Brawl Stars-inspired — bold black outlines, bright saturated colours, cartoon feel
**View:** Top-down, slight isometric tilt
**Frame size:** 48×48 px per frame
**All sprites face RIGHT**
**Background:** Transparent (RGBA PNG)

---

## Overview

Each character needs two new sprite sheets:
- **Idle** — standing still, breathing or gently bobbing (4 frames)
- **Walk** — legs and arms moving as they walk (6 frames)

The **attack sheets** from the previous brief already exist. The new sheets must match those characters exactly (same colours, same proportions, same art style).

---

## Idle Sheets — 4 frames each

Canvas: **192×48 px** (4 × 48 px frames, left to right)
Animation: gentle loop — breathing, slight bob, or small floating motion. Should feel relaxed.

| File | Character | Idle Suggestion |
|------|-----------|----------------|
| `player_wizard_idle.png` | Wizard (robe, pointed hat) | Staff held at side, robe sways slightly, hat bobs |
| `player_knight_idle.png` | Knight (armour, helmet) | Sword resting on shoulder, slight weight shift left/right |
| `player_assassin_idle.png` | Assassin (dark cloak, mask) | Arms crossed, cloak billows, eyes glance side to side |
| `player_miner_idle.png` | Miner (hard hat, overalls) | Pickaxe resting on ground, taps foot, chews something |
| `player_ninja_idle.png` | Ninja (dark gi, headband) | Balanced crouch stance, subtle ready-pose breathing |
| `player_robot_idle.png` | Robot (metal body, visor) | Arm cannon arm whirrs/rotates slightly, visor blinks |

---

## Walk Sheets — 6 frames each

Canvas: **288×48 px** (6 × 48 px frames, left to right)
Animation: smooth walk cycle — legs alternate, arms swing. The loop should be seamless (frame 6 flows back into frame 1).

| File | Character | Walk Notes |
|------|-----------|-----------|
| `player_wizard_walk.png` | Wizard | Robe flows behind, staff floats alongside |
| `player_knight_walk.png` | Knight | Armour clanks feel — stompy, deliberate stride |
| `player_assassin_walk.png` | Assassin | Light, fast steps — barely touching the ground |
| `player_miner_walk.png` | Miner | Heavy waddle — pickaxe bounces on shoulder |
| `player_ninja_walk.png` | Ninja | Fast smooth glide — almost silent, low to ground |
| `player_robot_walk.png` | Robot | Mechanical march — stiff legs, arms swing like pistons |

---

## Technical Requirements

- **File format:** PNG with transparency (RGBA)
- **Canvas sizes:**
  - Idle: exactly **192×48 px**
  - Walk: exactly **288×48 px**
- **Frame layout:** horizontal strip, all frames the same width, left to right
- **Drop location:** `assets/` folder (same folder as existing sheets)
- **Naming:** exact filenames listed above — the code matches on these names

---

## Delivery Checklist — 12 Files Total

```
assets/
  player_wizard_idle.png      (192×48)
  player_wizard_walk.png      (288×48)
  player_knight_idle.png      (192×48)
  player_knight_walk.png      (288×48)
  player_assassin_idle.png    (192×48)
  player_assassin_walk.png    (288×48)
  player_miner_idle.png       (192×48)
  player_miner_walk.png       (288×48)
  player_ninja_idle.png       (192×48)
  player_ninja_walk.png       (288×48)
  player_robot_idle.png       (192×48)
  player_robot_walk.png       (288×48)
```

No code changes needed — the game already looks for these files and will load them automatically.
