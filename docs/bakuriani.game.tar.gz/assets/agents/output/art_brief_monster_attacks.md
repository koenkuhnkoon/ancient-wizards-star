# Art Brief — Monster Walk & Attack Animations

**Game:** The Ancient Wizard's Star (Python/Pygame, top-down RPG)
**Style:** Brawl Stars-inspired — bold black outlines, bright saturated colours, cartoon feel
**View:** Top-down, slight isometric tilt
**Background:** Transparent (RGBA PNG)

---

## Overview

Each monster currently has a single static idle sprite. This brief adds:
- **Walk animations** (4 frames) — shown while chasing the player
- **Attack animations** (4 frames) — shown when the monster hits the player

The existing static sprite files (`enemy_evil_ninja.png` etc.) become the idle/
placeholder frame. The new sheets must match those characters exactly (same
colours, same proportions, same art style).

---

## Format

- **Frame layout:** Horizontal strip — all frames the same width, left to right
- **Loop:** Frame 4 flows back into Frame 1 seamlessly
- **All sprites face RIGHT** (the game flips them when needed)
- **Drop location:** `assets/` folder

---

## Walk Sheets — 4 frames each

Smooth walk cycle — body propelling the character forward.

### Regular Enemies

| File | Frame size | Strip canvas | Character | Walk notes |
|------|-----------|--------------|-----------|-----------|
| `enemy_evil_ninja_walk.png` | 44 × 44 px | **176 × 44 px** | Evil Ninja (dark gi, headband, sword) | Fast, light footwork — almost gliding. Feet barely touch the ground. Sword hand stays ready. |
| `enemy_skeleton_walk.png` | 44 × 48 px | **176 × 48 px** | Skeleton (white bones, hollow eye sockets) | Rickety bone shuffle — arms sway loosely, ribcage bounces. Jawbone slightly open. |
| `enemy_zombie_walk.png` | 44 × 48 px | **176 × 48 px** | Zombie (grey-green skin, tattered clothes) | Slow heavy lurch — one foot drags, arms hang forward. Very slow walk cycle. |
| `enemy_sewage_creature_walk.png` | 44 × 44 px | **176 × 44 px** | Sewage Creature (slimy blob with tentacles) | Slithering slide — body undulates side to side, tentacles ripple. |
| `enemy_land_octopus_walk.png` | 52 × 44 px | **208 × 44 px** | Land Octopus (orange, 8 tentacles) | Rolling gait — front 4 tentacles pull while back 4 push. Body bobs up and down. |
| `enemy_little_devil_walk.png` | 36 × 40 px | **144 × 40 px** | Little Devil (red, tiny wings, pitchfork) | Hops and flutters — wings beat every other step, tail swishes. |
| `enemy_poisonous_mushroom_walk.png` | 40 × 44 px | **160 × 44 px** | Poisonous Mushroom (purple cap, tiny legs) | Bouncy waddle — cap bobs vigorously up and down with each step. |
| `enemy_stonehead_turtle_walk.png` | 48 × 40 px | **192 × 40 px** | Stonehead Turtle (stone shell, rocky head) | Slow heavy plod — shell wobbles slightly, legs extend deliberately. |

### Mini-Bosses

| File | Frame size | Strip canvas | Character | Walk notes |
|------|-----------|--------------|-----------|-----------|
| `boss_grimrak_walk.png` | 80 × 80 px | **320 × 80 px** | Grimrak (giant stone golem, huge fists) | Slow ground-shaking stomp — each step lands heavily. Arms swing wide. Chest puffs with each stride. |
| `boss_zara_walk.png` | 64 × 64 px | **256 × 64 px** | Zara (storm witch, flowing robes, staff) | Gliding float — feet barely visible under robes. Robes trail behind. Staff held at side, arcing with energy. |

---

## Attack Sheets — 4 frames each

A snappy attack swing — the motion of the enemy landing a hit on the player.
Frame 1 is the wind-up; Frame 3–4 is the follow-through. Should feel impactful!

### Regular Enemies

| File | Frame size | Strip canvas | Attack description |
|------|-----------|--------------|-------------------|
| `enemy_evil_ninja_attack.png` | 44 × 44 px | **176 × 44 px** | Frame 1: sword raised behind; Frame 2: mid-slash diagonal; Frame 3: blade extended full forward with speed-lines; Frame 4: returning. Crisp and fast. |
| `enemy_skeleton_attack.png` | 44 × 48 px | **176 × 48 px** | Frame 1: arm raised high with bone club; Frame 2: beginning downward arc; Frame 3: full overhead slam, impact stars; Frame 4: recovering upright. |
| `enemy_zombie_attack.png` | 44 × 48 px | **176 × 48 px** | Frame 1: arms drooping forward; Frame 2: slow reach extending; Frame 3: full forward grab, fingers spread wide; Frame 4: arms retracting slowly. Very slow, deliberate. |
| `enemy_sewage_creature_attack.png` | 44 × 44 px | **176 × 44 px** | Frame 1: tentacle coiling back; Frame 2: tentacle mid-whip diagonally upward; Frame 3: full extension forward with slime splatter; Frame 4: tentacle retracting. |
| `enemy_land_octopus_attack.png` | 52 × 44 px | **208 × 44 px** | Frame 1: two front tentacles raised; Frame 2: both tentacles at peak; Frame 3: dual slam downward, impact ripple; Frame 4: tentacles recoiling. |
| `enemy_little_devil_attack.png` | 36 × 40 px | **144 × 40 px** | Frame 1: pitchfork pulled back; Frame 2: lunging forward, wings spread; Frame 3: pitchfork fully extended, sparks; Frame 4: pulling back with a grin. |
| `enemy_poisonous_mushroom_attack.png` | 40 × 44 px | **160 × 44 px** | Frame 1: cap inflating, storing pressure; Frame 2: cap fully puffed; Frame 3: spore cloud erupts forward (green puff); Frame 4: cap deflated, relaxing. |
| `enemy_stonehead_turtle_attack.png` | 48 × 40 px | **192 × 40 px** | Frame 1: head fully retracted into shell; Frame 2: head beginning to shoot out; Frame 3: head at full extension, stone neck stretched, impact; Frame 4: head snapping back in. |

### Mini-Bosses

| File | Frame size | Strip canvas | Attack description |
|------|-----------|--------------|-------------------|
| `boss_grimrak_attack.png` | 80 × 80 px | **320 × 80 px** | Frame 1: massive stone fist raised high; Frame 2: fist arcing downward; Frame 3: fist at ground level — huge dust and rock fragments explode; Frame 4: fist lifting, rubble settling. |
| `boss_zara_attack.png` | 64 × 64 px | **256 × 64 px** | Frame 1: staff raised, hands glowing purple; Frame 2: purple energy ball forming between hands; Frame 3: energy ball launches from outstretched palm, staff pointing; Frame 4: recovering pose, wisps of energy trailing. |

---

## Colour Reference for Consistency

Match these colours to the existing static sprites exactly:

| Character | Key colours |
|-----------|-------------|
| Evil Ninja | Dark navy (#1A1A2E), red headband, silver sword |
| Skeleton | Bone white (#F5F0DC), hollow dark eye sockets |
| Zombie | Grey-green skin (#7A9C5E), dark red blood accents, torn brown clothes |
| Sewage Creature | Murky brown-green (#5C7A3E), darker green slime |
| Land Octopus | Orange-brown (#CC6600), darker orange suction cups |
| Little Devil | Bright red (#CC2200), yellow horns, orange pitchfork |
| Poisonous Mushroom | Deep purple cap (#6600CC), pale spots, green toxic tinge |
| Stonehead Turtle | Stone grey (#888880) shell, darker grey rocky head |
| Grimrak | Dark charcoal stone (#333340), orange glowing cracks in body |
| Zara | Purple robes (#7722AA), silver hair, teal staff |

---

## Technical Requirements

- **File format:** PNG with transparency (RGBA)
- **Frame layout:** Horizontal strip, all frames the same width, left to right
- **No frame borders or gaps between frames**
- **Drop location:** `assets/` folder (same folder as existing enemy sprites)
- **Naming:** Exact filenames listed — the game code matches on these names

## Delivery Checklist — 20 Files Total

```
assets/
  # Walk sheets (4 frames each)
  enemy_evil_ninja_walk.png          (176×44)
  enemy_skeleton_walk.png            (176×48)
  enemy_zombie_walk.png              (176×48)
  enemy_sewage_creature_walk.png     (176×44)
  enemy_land_octopus_walk.png        (208×44)
  enemy_little_devil_walk.png        (144×40)
  enemy_poisonous_mushroom_walk.png  (160×44)
  enemy_stonehead_turtle_walk.png    (192×40)
  boss_grimrak_walk.png              (320×80)
  boss_zara_walk.png                 (256×64)

  # Attack sheets (4 frames each)
  enemy_evil_ninja_attack.png          (176×44)
  enemy_skeleton_attack.png            (176×48)
  enemy_zombie_attack.png              (176×48)
  enemy_sewage_creature_attack.png     (176×44)
  enemy_land_octopus_attack.png        (208×44)
  enemy_little_devil_attack.png        (144×40)
  enemy_poisonous_mushroom_attack.png  (160×44)
  enemy_stonehead_turtle_attack.png    (192×40)
  boss_grimrak_attack.png              (320×80)
  boss_zara_attack.png                 (256×64)
```
