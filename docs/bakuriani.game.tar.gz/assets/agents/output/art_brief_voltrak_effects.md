# Art Brief — Voltrak, Boss Effects & Arena Tiles

**Game:** The Ancient Wizard's Star (Python/Pygame, top-down RPG)
**Style:** Brawl Stars-inspired — bold black outlines, bright saturated colours, cartoon feel
**View:** Top-down, slight isometric tilt
**Background:** Transparent (RGBA PNG)

---

## Overview

This brief covers Voltrak (the final boss), visual effect sprites for boss special
attacks, the Voltrak arena tiles, and the Summoner NPC. These are needed for the
boss-fight upgrade: Grimrak gets a ground slam, Zara fires magic bolts, Voltrak
has an electric bolt spread and shockwave.

---

## 1. Boss Sprite — Voltrak the Shockblade Eel

| File | Canvas size |
|------|-------------|
| `boss_voltrak.png` | **128 × 64 px** (single frame, no strip) |

**Description:**
Voltrak is a massive ninja land-eel — long, sinuous eel body wearing samurai
armour plates bolted along his spine. He holds a glowing electric sword (yellow/
white blade with arcing sparks) extending in front of him. Electric energy crackles
along his body in short blue-white arcs. His eyes glow bright yellow.

- **Colour palette:** Dark navy body, gold/bronze armour plates, electric yellow
  sword and sparks, bright yellow glowing eyes
- **Pose:** Facing RIGHT, body slightly curved (S-shape), sword tip pointing forward
- **Black outline:** Bold, 2 px minimum
- **Transparent background (RGBA)**

---

## 2. Boss Attack Effects

### 2a. Grimrak Ground Slam Ring

| File | Frame size | Frames | Strip size |
|------|-----------|--------|------------|
| `fx_boss_slam.png` | 160 × 160 px | 4 | **640 × 160 px** |

**Description:**
An expanding ring of cracked stone and orange energy — Grimrak's fist smash
radiating outward from the impact point.

- Frame 1: Small crack, radius ~20 px, bright orange centre glow
- Frame 2: Ring expands to ~60 px radius, crack lines radiate outward
- Frame 3: Ring at ~100 px radius, glow fading to amber
- Frame 4: Ring at full ~130 px radius, mostly faded, dust particles

All frames: transparent outside the effect area.
Colour: orange-amber cracks, dusty brown particles, dark stone fragments.

---

### 2b. Zara Magic Bolt

| File | Frame size | Frames | Strip size |
|------|-----------|--------|------------|
| `fx_zara_bolt.png` | 16 × 16 px | 4 | **64 × 16 px** |

**Description:**
A small glowing purple orb with trailing sparkle — Zara's projectile magic bolt.
Travels in a straight line toward the player.

- Frame 1: Solid bright purple orb, full opacity
- Frame 2: Orb with a short trailing sparkle tail
- Frame 3: Orb slightly larger, sparkles flaring outward
- Frame 4: Back to compact orb (loops smoothly)

Colour: purple (#B400FF) core, pink-white sparkle, slight outer glow.

---

### 2c. Voltrak Electric Bolt

| File | Frame size | Frames | Strip size |
|------|-----------|--------|------------|
| `fx_voltrak_bolt.png` | 20 × 8 px | 4 | **80 × 8 px** |

**Description:**
A short electric bolt dart — Voltrak's ranged projectile. Thin, lightning-bolt
shaped, travels fast.

- Frame 1: Solid yellow-white dart, jagged shape
- Frame 2: Same dart with thin electric arc above it
- Frame 3: Dart with flicker effect (slightly thicker)
- Frame 4: Slim dart with trailing white spark

Colour: bright yellow (#FFE000) body, white (#FFFFFF) core flicker, faint blue
outer fringe.

---

### 2d. Voltrak Shockwave Ring

| File | Frame size | Frames | Strip size |
|------|-----------|--------|------------|
| `fx_voltrak_shockwave.png` | 256 × 256 px | 4 | **1024 × 256 px** |

**Description:**
A large expanding electric ring radiating outward from Voltrak's body — his
area-of-effect shockwave attack.

- Frame 1: Thin ring, radius ~60 px, bright yellow with electric detail
- Frame 2: Ring expands to ~120 px, starts to fragment into arc segments
- Frame 3: Ring at ~180 px, fragments with gaps, fading to pale yellow
- Frame 4: Ring at ~220 px, mostly transparent wisps

Colour: electric yellow (#FFE000) to white core, blue fringe (#44AAFF), transparent
outside the ring.

---

## 3. Summoner NPC

| File | Size |
|------|------|
| `npc_summoner.png` | **44 × 44 px** (single frame) |

**Description:**
An old friendly wizard who summons companions for the player. Short, round, wearing
a star-patterned deep blue robe and a wide-brimmed pointed hat. Holds a glowing
lantern in one hand; small golden runes float around him.

- **Expression:** Warm, welcoming smile; rosy cheeks
- **Colour:** Deep blue robe with gold stars, orange lantern glow, white beard
- **Style:** Brawl Stars cartoon feel — bold outline, big eyes, slightly chubby proportions
- **Transparent background (RGBA)**

---

## 4. Companion Summon Effect

| File | Frame size | Frames | Strip size |
|------|-----------|--------|------------|
| `fx_summon_appear.png` | 48 × 48 px | 6 | **288 × 48 px** |

**Description:**
A sparkle burst in gold that appears at the spot where a CompanionFighter is
summoned — like a heroic magical materialisation.

- Frame 1: Small golden seed glow, centre only
- Frame 2: 4 bright star-points shooting outward
- Frame 3: Full 8-point starburst, maximum size
- Frame 4: Starburst with trailing sparkles, starts shrinking
- Frame 5: Smaller burst, sparkles falling
- Frame 6: Just a few final golden particles fading out

Colour: bright gold (#FFD700), white centre core, soft yellow outer glow.

---

## 5. Arena Tiles (for Voltrak's Dark Arena)

### 5a. Electric Danger Pit Tile (animated)

| File | Frame size | Frames | Strip size |
|------|-----------|--------|------------|
| `tile_electric.png` | 32 × 32 px | 4 | **128 × 32 px** |

**Description:**
An animated floor tile for the corners of Voltrak's arena — a crackling electric
pit that pulses with dangerous energy.

- All 4 frames show: dark stone border/rim, glowing energy pool in the centre
- Frame 1: Dim glow, scattered sparks
- Frame 2: Brighter, one larger spark arc
- Frame 3: Brightest — large energy burst in the middle
- Frame 4: Fading back to dim, small residual sparks

Colour: dark stone grey border, electric yellow-orange energy (#FFB000), white
spark highlights.

---

### 5b. Stone Floor Tile

| File | Size |
|------|------|
| `tile_stone.png` | **32 × 32 px** (single frame) |

**Description:**
A plain dark stone floor tile for the interior of Voltrak's arena. Matches the
style of existing world tiles (`tile_dirt.png`, `tile_grass.png`).

- Dark grey/slate colour (#555060)
- Subtle stone slab texture — faint mortar lines between blocks
- Slight top-down shading (slightly lighter at the top)
- Bold black outline along edges to match tile grid feel
- No transparency needed (filled tile)

---

## Technical Requirements

- **File format:** PNG with transparency (RGBA) — except `tile_stone.png` which can be opaque
- **Frame layout:** Horizontal strip, frames left to right, all frames same width
- **Drop location:** `assets/` folder (same folder as all existing sprites)
- **Naming:** Exact filenames listed above — the code matches on these names

## Delivery Checklist — 9 Files Total

```
assets/
  boss_voltrak.png             (128×64)
  fx_boss_slam.png             (640×160, 4 frames)
  fx_zara_bolt.png             (64×16, 4 frames)
  fx_voltrak_bolt.png          (80×8, 4 frames)
  fx_voltrak_shockwave.png     (1024×256, 4 frames)
  npc_summoner.png             (44×44)
  fx_summon_appear.png         (288×48, 6 frames)
  tile_electric.png            (128×32, 4 frames)
  tile_stone.png               (32×32)
```
