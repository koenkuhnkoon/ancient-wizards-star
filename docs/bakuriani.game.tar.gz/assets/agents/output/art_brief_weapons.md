# Art Brief — Weapons & Attack Effects

**Game:** The Ancient Wizard's Star (Python/Pygame, top-down RPG)
**Style:** Brawl Stars-inspired — bold black outlines, bright saturated colors, cartoon feel
**View:** Top-down, slight isometric tilt
**Player sprite size:** 48×48 px per frame

---

## Part 1 — Attack Effect Sprites

These flash on screen when a character attacks, showing the damage zone.
Each file is a horizontal sprite sheet. All frames are the same size, laid out left to right.
Transparent background (RGBA PNG).

| File | Canvas | Frames | Frame size | Description |
|------|--------|--------|------------|-------------|
| `fx_attack_staff.png` | 400×100 px | 4 | 100×100 px | Purple/violet magic burst radiating outward from center — glowing orb expanding into sparkles |
| `fx_attack_sword.png` | 320×50 px | 4 | 80×50 px | Golden slash arc sweeping left-to-right — motion blur lines, bright yellow-white edge |
| `fx_attack_daggers.png` | 80×32 px | 2 | 40×32 px | Quick silver stab flash — short sharp lines pointing right, slight red tint at tip |
| `fx_attack_pickaxe.png` | 440×40 px | 4 | 110×40 px | Orange/brown wide arc sweep — dust cloud with impact chips flying off |

Frame order = animation sequence, left to right.

---

## Part 2 — Projectile Sprites

Moving objects fired by Ninja (shuriken) and Robot (laser).
Horizontal sprite sheet, transparent background (RGBA PNG).
Sprites face right — the game will flip them if needed.

| File | Canvas | Frames | Frame size | Description |
|------|--------|--------|------------|-------------|
| `fx_projectile_shuriken.png` | 56×14 px | 4 | 14×14 px | Silver-blue spinning throwing star — 4-pointed, each frame rotated 22.5°, glowing edge |
| `fx_projectile_laser.png` | 48×8 px | 2 | 24×8 px | Cyan laser bolt — elongated capsule, bright white core with cyan glow, second frame slightly dimmer |

---

## Part 3 — Character Attack Sheets

Each file: **192×48 px total**, 4 frames of 48×48 px, character facing right, transparent background.
Frame 1 = wind-up, Frame 4 = follow-through.

| File | Character | Weapon | Notes |
|------|-----------|--------|-------|
| `player_wizard_attack.png` | Wizard (robe, pointed hat) | Magic wand/staff | Wand raised, tip glowing purple, arms extended for area cast |
| `player_knight_attack.png` | Knight (armour, helmet) | Broadsword | Sword raised overhead in frame 1, swinging forward by frame 4 |
| `player_assassin_attack.png` | Assassin (dark cloak, mask) | Short dagger | Low crouch, dagger thrusting forward, quick motion |
| `player_miner_attack.png` | Miner (hard hat, overalls) | Pickaxe | Pickaxe raised high in frame 1, swinging down-forward by frame 4 |
| `player_ninja_attack.png` | Ninja (dark gi, headband) | Throwing star | Arm cocked back in frame 1, releasing shuriken by frame 3, follow-through in frame 4 |
| `player_robot_attack.png` | Robot (metal body, visor) | Arm cannon / laser | Arm transforms into cannon in frame 1, charging glow in frames 2-3, firing beam in frame 4 |

---

## Delivery

- All files saved as **PNG with transparency (RGBA)**
- Drop into the `assets/` folder (flat — no subfolders needed)
- 11 files total: 4 attack effects + 2 projectiles + 5 character attack sheets

## Quick Reference — All 11 Files

```
assets/
  fx_attack_staff.png
  fx_attack_sword.png
  fx_attack_daggers.png
  fx_attack_pickaxe.png
  fx_projectile_shuriken.png
  fx_projectile_laser.png
  player_wizard_attack.png
  player_knight_attack.png
  player_assassin_attack.png
  player_miner_attack.png
  player_ninja_attack.png
  player_robot_attack.png
```
