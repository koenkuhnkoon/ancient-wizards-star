# Updated: main.py

## Changes Made
- **BUG FIX (HIGH)** — Font performance fix: `hud_font` is now created once inside `main()` right after `pygame.init()`, before the game loop starts. The old code already passed `hud_font` as a parameter to `draw_hud()`, which is good — we just made sure the font is created in only one place and never inside any loop. Added a clear comment explaining WHY this matters for 60 FPS.
- **LOW fix** — Added named constants for magic numbers on the character selection screen (`SELECT_TITLE_Y`, `SELECT_SUBTITLE_Y`, `SELECT_OPTIONS_Y`, `SELECT_OPTION_GAP`, `SELECT_HINT_OFFSET`) and for the HUD label offsets (`HUD_LABEL_GAP_X`, `HUD_LABEL_NUDGE_Y`). The drawing code now uses these named constants instead of bare numbers.
- **New Feature 1: ESC = Return to Menu** — In the game loop, pressing ESC now returns the player to the character selection screen instead of quitting entirely. The character selection screen now also exits cleanly when ESC is pressed or the window is closed. A small "ESC = Menu" hint is drawn in the bottom-right corner of the game screen.
- **New Feature 2: Pause / Options Screen** — Pressing P during gameplay shows a pause overlay. The overlay dims the game behind it, shows a "PAUSED" title (in gold), a CONTROLS section listing all keys, and a SETTINGS section with an Audio ON/OFF toggle. Up/Down arrows navigate between settings items; Enter or Space toggles the selected item; P or ESC unpauses.
- **BUG FIX (MEDIUM)** — Added `NUM_SETTINGS = 1` constant near the pause menu constants (with a comment to update it when more settings are added). Fixed the DOWN arrow handler: changed `min(0, selected_setting_index + 1)` to `min(NUM_SETTINGS - 1, selected_setting_index + 1)`. The old code used `min(0, ...)` which always returned 0, silently breaking navigation the moment a second setting is ever added.
- **LOW fix** — Removed the duplicate `SELECT_HIGHLIGHT` constant (it had the same value as `HERO_GOLD`). All places that used `SELECT_HIGHLIGHT` now use `HERO_GOLD` directly, keeping a single source of truth for that color.
- **LOW fix** — Changed the footer hint in the pause overlay from "Up/Down = Select" to "Up/Down = Navigate" — more accurate wording, and future-proof for when more settings are added.

## Code

```python
# ============================================================
# main.py — The Ancient Wizard's Star
#
# This is the very first file Python runs when the game starts.
# It sets up the screen, runs the character selection, and then
# kicks off the main game loop where all the action happens!
# ============================================================

import asyncio
import pygame

# We import the Player class from the game folder
from game.player import Player

# ── Screen & Game Constants ────────────────────────────────
# Keeping numbers up here with names makes them easy to find and change.

SCREEN_WIDTH  = 1280   # How wide the game window is, in pixels
SCREEN_HEIGHT =  720   # How tall the game window is, in pixels
TARGET_FPS    =   60   # We want the game to run at 60 frames per second — super smooth!
GAME_TITLE    = "The Ancient Wizard's Star"

# ── Background Color ───────────────────────────────────────
GRASS_GREEN = (76, 175, 80)   # A cheerful green for the placeholder world background

# ── HUD (Heads-Up Display) Constants ──────────────────────
# The HUD is the info overlay drawn on top of the game — health bars, energy bars, etc.
# These positions and sizes come directly from the Art Guide.

HEALTH_BAR_X      =  12    # How far from the left edge the health bar starts
HEALTH_BAR_Y      =  12    # How far from the top edge the health bar starts
HEALTH_BAR_WIDTH  = 120    # Total width of the health bar
HEALTH_BAR_HEIGHT =  16    # Height of the health bar

ENERGY_BAR_X      =  12    # Same left edge as the health bar — they line up neatly
ENERGY_BAR_Y      =  34    # A little lower than the health bar
ENERGY_BAR_WIDTH  = 120
ENERGY_BAR_HEIGHT =  16

PORTRAIT_X      =  12    # Character portrait position (top-left corner of the portrait box)
PORTRAIT_Y      =  60
PORTRAIT_SIZE   =  48    # The portrait is a 48 x 48 square

# Spacing between the right edge of a bar and its text label
HUD_LABEL_GAP_X   =   6   # Pixels of space between the bar and the "HP" / "EN" text
HUD_LABEL_NUDGE_Y =   1   # Tiny downward nudge so the text lines up with the center of the bar

# ── HUD Colors ─────────────────────────────────────────────
# From the Art Guide — these exact colors were chosen by the graphic designer!

HEALTH_BAR_FILL_COLOR  = (231,  76,  60)   # #E74C3C — bright red for current health
HEALTH_BAR_BG_COLOR    = ( 90,  26,  26)   # #5A1A1A — dark red for the empty part of the bar
ENERGY_BAR_FILL_COLOR  = (  0, 229, 255)   # #00E5FF — bright cyan for current energy
ENERGY_BAR_BG_COLOR    = (  0,  58,  69)   # #003A45 — dark cyan for the empty part of the bar
PORTRAIT_BORDER_COLOR  = (245, 200,  66)   # #F5C842 — hero gold for the portrait frame
OUTLINE_BLACK          = ( 26,  26,  26)   # #1A1A1A — very dark outline color
HERO_GOLD              = (245, 200,  66)   # #F5C842 — used for titles and highlights

# Colors used on the character selection screen
SELECT_SCREEN_BG    = ( 20,  20,  40)   # Very dark blue — feels magical
SELECT_SCREEN_TEXT  = (255, 255, 255)   # White text so it's easy to read
# Note: gold color on the selection screen uses HERO_GOLD defined above

# The six playable character classes, in the order keys 1–6 select them
CHARACTER_CLASSES = ["Wizard", "Knight", "Assassin", "Miner", "Ninja", "Robot"]

# ── Character Selection Screen Layout Constants ────────────
# Using named constants here means if we ever want to move things around,
# we only need to change the number in ONE place, not hunt through all the code!

SELECT_TITLE_Y    =  80   # Y position of the big gold title
SELECT_SUBTITLE_Y = 160   # Y position of the "Choose Your Hero!" subtitle
SELECT_OPTIONS_Y  = 230   # Y position of the first class option in the list
SELECT_OPTION_GAP =  45   # How many pixels apart each option is spaced vertically
SELECT_HINT_OFFSET =  60  # How many pixels up from the bottom of the screen the hint sits

# ── Pause Screen Constants ─────────────────────────────────
# Colors and sizes for the pause / options overlay

PAUSE_OVERLAY_COLOR  = (  0,   0,   0, 160)  # Black with alpha 160 — semi-transparent dim
PAUSE_PANEL_COLOR    = ( 20,  20,  40, 230)  # Dark blue panel, mostly opaque
PAUSE_TITLE_COLOR    = (245, 200,  66)        # #F5C842 Hero Gold — for "PAUSED" and section headings
PAUSE_BODY_COLOR     = (255, 255, 255)        # White — for regular text items
PAUSE_SELECT_COLOR   = (245, 200,  66)        # Gold highlight on the currently selected setting
PAUSE_PANEL_WIDTH    = 520   # How wide the pause panel is, in pixels
PAUSE_PANEL_HEIGHT   = 400   # How tall the pause panel is, in pixels

# How many items are in the SETTINGS section of the pause menu.
# Update this number when you add more settings to the pause menu!
NUM_SETTINGS = 1   # Right now there is only one setting: Audio ON/OFF


# ── Helper: Draw the HUD ───────────────────────────────────

def draw_hud(screen, player, hud_font):
    """Draw the health bar, energy bar, and character portrait onto the screen."""

    # ── Health Bar ─────────────────────────────────────────
    # First draw the dark background bar (represents missing health)
    health_bg_rect = pygame.Rect(HEALTH_BAR_X, HEALTH_BAR_Y, HEALTH_BAR_WIDTH, HEALTH_BAR_HEIGHT)
    pygame.draw.rect(screen, HEALTH_BAR_BG_COLOR, health_bg_rect)

    # Then draw the bright filled portion on top (represents remaining health)
    # get_health_fraction() gives us a number 0.0 to 1.0 so we can scale the bar width
    health_fill_width = int(HEALTH_BAR_WIDTH * player.get_health_fraction())
    if health_fill_width > 0:   # Only draw the fill if there is health remaining
        health_fill_rect = pygame.Rect(HEALTH_BAR_X, HEALTH_BAR_Y, health_fill_width, HEALTH_BAR_HEIGHT)
        pygame.draw.rect(screen, HEALTH_BAR_FILL_COLOR, health_fill_rect)

    # Thin outline around the whole health bar so it looks crisp
    pygame.draw.rect(screen, OUTLINE_BLACK, health_bg_rect, width=1)

    # ── Energy Bar ─────────────────────────────────────────
    # Same idea as the health bar, but uses cyan colors and sits below the health bar
    energy_bg_rect = pygame.Rect(ENERGY_BAR_X, ENERGY_BAR_Y, ENERGY_BAR_WIDTH, ENERGY_BAR_HEIGHT)
    pygame.draw.rect(screen, ENERGY_BAR_BG_COLOR, energy_bg_rect)

    energy_fill_width = int(ENERGY_BAR_WIDTH * player.get_energy_fraction())
    if energy_fill_width > 0:   # Only draw fill if there is energy left
        energy_fill_rect = pygame.Rect(ENERGY_BAR_X, ENERGY_BAR_Y, energy_fill_width, ENERGY_BAR_HEIGHT)
        pygame.draw.rect(screen, ENERGY_BAR_FILL_COLOR, energy_fill_rect)

    pygame.draw.rect(screen, OUTLINE_BLACK, energy_bg_rect, width=1)

    # ── Character Portrait ─────────────────────────────────
    # For now this is just a gold-bordered box — real portrait art comes later!
    portrait_rect = pygame.Rect(PORTRAIT_X, PORTRAIT_Y, PORTRAIT_SIZE, PORTRAIT_SIZE)
    pygame.draw.rect(screen, PORTRAIT_BORDER_COLOR, portrait_rect, width=3)   # Gold border, 3 pixels thick

    # ── HUD Labels ─────────────────────────────────────────

    # "HP" label to the right of the health bar
    hp_label = hud_font.render(f"HP  {player.health}/{player.max_health}", True, (255, 255, 255))
    screen.blit(hp_label, (HEALTH_BAR_X + HEALTH_BAR_WIDTH + HUD_LABEL_GAP_X, HEALTH_BAR_Y + HUD_LABEL_NUDGE_Y))

    # "EN" label to the right of the energy bar
    en_label = hud_font.render(f"EN  {player.energy}/{player.max_energy}", True, (255, 255, 255))
    screen.blit(en_label, (ENERGY_BAR_X + ENERGY_BAR_WIDTH + HUD_LABEL_GAP_X, ENERGY_BAR_Y + HUD_LABEL_NUDGE_Y))


# ── Helper: Draw the "ESC = Menu" hint ────────────────────

def draw_esc_hint(screen, hint_font):
    """Draw a small hint in the bottom-right corner reminding the player how to return to the menu."""

    hint_surface = hint_font.render("ESC = Menu", True, (200, 200, 200))  # Light grey — unobtrusive

    # Position it 10 pixels from the right and bottom edges of the screen
    hint_x = SCREEN_WIDTH  - hint_surface.get_width()  - 10
    hint_y = SCREEN_HEIGHT - hint_surface.get_height() - 10

    screen.blit(hint_surface, (hint_x, hint_y))


# ── Helper: Draw the Pause Overlay ────────────────────────

def draw_pause_overlay(screen, pause_fonts, audio_enabled, selected_setting_index):
    """Draw the full-screen pause overlay with CONTROLS and SETTINGS sections.

    pause_fonts     — a dict with keys 'title', 'section', 'body' holding font objects
    audio_enabled   — True if audio is ON, False if audio is OFF
    selected_setting_index — which SETTINGS item is highlighted (0 = Audio toggle for now)
    """

    # ── Dim the game behind the panel ──────────────────────
    # We create a temporary surface the size of the whole screen, fill it with
    # a semi-transparent black, then draw it on top of the game world.
    # This "dims" everything so the menu is easy to read.
    dim_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    dim_surface.fill(PAUSE_OVERLAY_COLOR)   # SRCALPHA lets us use transparency (the 4th number)
    screen.blit(dim_surface, (0, 0))

    # ── Draw the dark panel in the center ──────────────────
    # The panel is a solid rectangle that sits on top of the dim layer.
    panel_x = SCREEN_WIDTH  // 2 - PAUSE_PANEL_WIDTH  // 2   # Center horizontally
    panel_y = SCREEN_HEIGHT // 2 - PAUSE_PANEL_HEIGHT // 2   # Center vertically

    panel_surface = pygame.Surface((PAUSE_PANEL_WIDTH, PAUSE_PANEL_HEIGHT), pygame.SRCALPHA)
    panel_surface.fill(PAUSE_PANEL_COLOR)
    screen.blit(panel_surface, (panel_x, panel_y))

    # Gold border around the panel so it looks clean
    panel_rect = pygame.Rect(panel_x, panel_y, PAUSE_PANEL_WIDTH, PAUSE_PANEL_HEIGHT)
    pygame.draw.rect(screen, HERO_GOLD, panel_rect, width=2)

    # ── "PAUSED" title at the top of the panel ─────────────
    title_surface = pause_fonts["title"].render("PAUSED", True, PAUSE_TITLE_COLOR)
    title_x = SCREEN_WIDTH // 2 - title_surface.get_width() // 2   # Center it
    screen.blit(title_surface, (title_x, panel_y + 20))

    # ── CONTROLS section ───────────────────────────────────
    # This tells the player what every key does, so they never feel lost!
    controls_heading = pause_fonts["section"].render("CONTROLS", True, PAUSE_TITLE_COLOR)
    screen.blit(controls_heading, (panel_x + 30, panel_y + 80))

    # List every control, one line at a time
    controls_list = [
        "Arrow Keys / WASD  =  Move",
        "Shift              =  Run",
        "P                  =  Pause / Unpause",
        "ESC                =  Return to Menu",
    ]

    for line_index, control_text in enumerate(controls_list):
        # line_index goes 0, 1, 2, 3 — multiply by 26 to space lines 26 pixels apart
        line_surface = pause_fonts["body"].render(control_text, True, PAUSE_BODY_COLOR)
        line_y = panel_y + 110 + line_index * 26
        screen.blit(line_surface, (panel_x + 30, line_y))

    # ── SETTINGS section ───────────────────────────────────
    settings_heading = pause_fonts["section"].render("SETTINGS", True, PAUSE_TITLE_COLOR)
    screen.blit(settings_heading, (panel_x + 30, panel_y + 240))

    # Audio toggle — shows ON or OFF depending on the current state
    audio_state_text = "ON" if audio_enabled else "OFF"
    audio_text = f"Audio:  {audio_state_text}"

    # Highlight the audio option in gold if it is currently selected, otherwise white
    audio_color = PAUSE_SELECT_COLOR if selected_setting_index == 0 else PAUSE_BODY_COLOR

    # Draw a small arrow ">" before the selected item so the player can see which one is highlighted
    if selected_setting_index == 0:
        arrow_surface = pause_fonts["body"].render(">", True, PAUSE_SELECT_COLOR)
        screen.blit(arrow_surface, (panel_x + 15, panel_y + 270))

    audio_surface = pause_fonts["body"].render(audio_text, True, audio_color)
    screen.blit(audio_surface, (panel_x + 30, panel_y + 270))

    # ── Footer hint at the bottom of the panel ─────────────
    footer_text = "P or ESC = Unpause   |   Up/Down = Navigate   |   Enter/Space = Toggle"
    footer_surface = pause_fonts["body"].render(footer_text, True, (160, 160, 160))  # Grey — subtle
    footer_x = SCREEN_WIDTH // 2 - footer_surface.get_width() // 2
    screen.blit(footer_surface, (footer_x, panel_y + PAUSE_PANEL_HEIGHT - 35))


# ── Helper: Character Selection Screen ────────────────────

async def run_character_selection(screen, clock, fonts):
    """Show the character selection screen and return the class the player chose.

    Returns the chosen class name (e.g. "Wizard"), or None if the player quit.

    fonts — a dict with keys 'big', 'small', 'hint' holding font objects created
            once in main() before this function is called.
    """

    # We keep looping until the player presses a key 1–6 or presses ESC / closes the window
    chosen_class = None

    # Map each number key to a character class
    key_to_class = {
        pygame.K_1: CHARACTER_CLASSES[0],   # 1 → Wizard
        pygame.K_2: CHARACTER_CLASSES[1],   # 2 → Knight
        pygame.K_3: CHARACTER_CLASSES[2],   # 3 → Assassin
        pygame.K_4: CHARACTER_CLASSES[3],   # 4 → Miner
        pygame.K_5: CHARACTER_CLASSES[4],   # 5 → Ninja
        pygame.K_6: CHARACTER_CLASSES[5],   # 6 → Robot
    }

    while chosen_class is None:
        # Handle events so the window doesn't freeze
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None   # Player closed the window — signal the game to exit completely

            if event.type == pygame.KEYDOWN:
                # Check if they pressed a key that maps to a class
                if event.key in key_to_class:
                    chosen_class = key_to_class[event.key]

                # ESC on the selection screen quits the game entirely
                elif event.key == pygame.K_ESCAPE:
                    return None   # None means "exit the whole game"

        # ── Draw the selection screen ──────────────────────
        screen.fill(SELECT_SCREEN_BG)   # Dark blue background feels mysterious

        # Big gold title at the top
        title_surface = fonts["big"].render(GAME_TITLE, True, HERO_GOLD)
        title_x = SCREEN_WIDTH // 2 - title_surface.get_width() // 2   # Center horizontally
        screen.blit(title_surface, (title_x, SELECT_TITLE_Y))

        # Subtitle
        sub_surface = fonts["small"].render("Choose Your Hero!", True, SELECT_SCREEN_TEXT)
        sub_x = SCREEN_WIDTH // 2 - sub_surface.get_width() // 2
        screen.blit(sub_surface, (sub_x, SELECT_SUBTITLE_Y))

        # List each class with its key number
        for index, class_name in enumerate(CHARACTER_CLASSES):
            # index goes 0, 1, 2, 3, 4, 5 — we add 1 so keys show as 1–6
            option_text = f"  {index + 1}  —  {class_name}"
            option_surface = fonts["small"].render(option_text, True, SELECT_SCREEN_TEXT)
            option_x = SCREEN_WIDTH // 2 - option_surface.get_width() // 2
            option_y = SELECT_OPTIONS_Y + index * SELECT_OPTION_GAP   # Stack options with the named gap
            screen.blit(option_surface, (option_x, option_y))

        # Small hint at the bottom — gold color so it stands out
        hint_surface = fonts["hint"].render("Press 1 - 6 to choose your character   |   ESC = Quit", True, HERO_GOLD)
        hint_x = SCREEN_WIDTH // 2 - hint_surface.get_width() // 2
        screen.blit(hint_surface, (hint_x, SCREEN_HEIGHT - SELECT_HINT_OFFSET))

        pygame.display.flip()   # Show everything we just drew
        clock.tick(TARGET_FPS)
        await asyncio.sleep(0)  # REQUIRED for pygbag — lets the browser breathe

    return chosen_class


# ── Main Game Loop ─────────────────────────────────────────

async def main():
    """Set up pygame and run the game from start to finish."""

    # Initialize pygame — this must happen before anything else
    pygame.init()

    # ── Create all fonts HERE, once, right after pygame.init() ────────────
    # WHY here and not inside draw functions?
    # Loading a font from the system is slow — it reads a file and builds a
    # whole font object. If we did that inside draw_hud() or draw() it would
    # happen 60 times per second, making the game slow and stuttery.
    # Creating fonts once here means we do that work only one time, then
    # reuse the same font object for every single frame. Fast!

    hud_font  = pygame.font.SysFont("Arial", 11)   # Small font for HP / EN labels in the HUD
    hint_font = pygame.font.SysFont("Arial", 13)   # Slightly larger for the "ESC = Menu" corner hint

    # Fonts for the character selection screen
    select_fonts = {
        "big":   pygame.font.SysFont("Arial", 48, bold=True),  # Big bold title
        "small": pygame.font.SysFont("Arial", 24),              # Class option list
        "hint":  pygame.font.SysFont("Arial", 18),              # Small hint at the bottom
    }

    # Fonts for the pause overlay
    pause_fonts = {
        "title":   pygame.font.SysFont("Arial", 42, bold=True),  # "PAUSED"
        "section": pygame.font.SysFont("Arial", 22, bold=True),  # "CONTROLS" / "SETTINGS"
        "body":    pygame.font.SysFont("Arial", 18),              # Individual items
    }

    # Create the game window
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption(GAME_TITLE)   # Text shown in the window title bar

    # The clock keeps our game running at exactly 60 frames per second
    clock = pygame.time.Clock()

    # ── Outer loop: keeps going back to the menu instead of quitting ───────
    # When the player presses ESC in-game, we want to return to character
    # selection, not exit the whole program. So we wrap everything in a loop
    # that only stops when the player truly wants to quit.

    app_running = True   # Set to False only when we want to exit completely

    while app_running:

        # ── Character Selection ────────────────────────────
        # Before the game starts, let the player pick who they want to be
        chosen_class = await run_character_selection(screen, clock, select_fonts)

        # If chosen_class is None, the player closed the window or pressed ESC on the menu
        if chosen_class is None:
            app_running = False   # Exit the whole program
            break

        # ── Create the Player ──────────────────────────────
        # Now that we know the class, we can build the player object
        player = Player(chosen_class, SCREEN_WIDTH, SCREEN_HEIGHT)

        # ── Pause state ────────────────────────────────────
        game_paused = False          # Is the game currently paused?
        audio_enabled = True         # Audio ON by default (placeholder — no sound system yet)
        selected_setting_index = 0   # Which SETTINGS item the cursor is on (0 = Audio toggle)

        # ── Game Loop ──────────────────────────────────────
        # This loop runs once every frame (up to 60 times per second).
        # It exits when the player presses ESC (return to menu) or closes the window.

        game_running = True
        while game_running:

            # ── Handle Events ──────────────────────────────
            # Events are things the player does: pressing keys, clicking the mouse, closing the window
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    # Player closed the window — exit everything
                    game_running = False
                    app_running  = False

                if event.type == pygame.KEYDOWN:

                    # ── ESC: return to character selection ──
                    if event.key == pygame.K_ESCAPE:
                        if game_paused:
                            # If paused, ESC just unpauses (same as pressing P)
                            game_paused = False
                        else:
                            # If not paused, ESC goes back to the character selection screen
                            game_running = False   # Exit the inner game loop; outer loop shows menu

                    # ── P: toggle the pause menu ────────────
                    elif event.key == pygame.K_p:
                        game_paused = not game_paused   # Flip between paused and unpaused

                    # ── Keys that only work while PAUSED ────
                    elif game_paused:

                        if event.key == pygame.K_UP:
                            # Move the selection cursor up (wrap around at the top)
                            selected_setting_index = max(0, selected_setting_index - 1)

                        elif event.key == pygame.K_DOWN:
                            # Move the selection cursor down.
                            # NUM_SETTINGS tells us how many items are in the list — we stop at the last one.
                            selected_setting_index = min(NUM_SETTINGS - 1, selected_setting_index + 1)

                        elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                            # Toggle whichever setting is currently selected
                            if selected_setting_index == 0:
                                audio_enabled = not audio_enabled   # Flip ON/OFF

            # ── Update ─────────────────────────────────────
            # Only update (move) the player if the game is NOT paused.
            # While paused, the world freezes but we still draw the overlay.

            if not game_paused:
                # Read which keys are being held down right now
                keys_pressed = pygame.key.get_pressed()

                # Move the player based on the keys they're holding
                player.handle_input(keys_pressed)

                # Make sure the player can't walk off the screen
                player.keep_on_screen(SCREEN_WIDTH, SCREEN_HEIGHT)

            # ── Draw ───────────────────────────────────────
            # We draw in layers — background first, then characters, then HUD on top

            # 1. Fill the whole screen with green to represent the ground/grass
            screen.fill(GRASS_GREEN)

            # 2. Draw the player character on top of the background
            player.draw(screen)

            # 3. Draw the HUD (health/energy bars) on top of everything
            draw_hud(screen, player, hud_font)

            # 4. Draw the "ESC = Menu" hint in the bottom-right corner
            draw_esc_hint(screen, hint_font)

            # 5. If the game is paused, draw the pause overlay on top of everything
            if game_paused:
                draw_pause_overlay(screen, pause_fonts, audio_enabled, selected_setting_index)

            # ── Show the Frame ─────────────────────────────
            pygame.display.flip()   # Flip sends everything we drew to the actual screen

            # Wait just long enough so we run at 60 FPS (not faster, not much slower)
            clock.tick(TARGET_FPS)

            # REQUIRED for pygbag — this tiny pause lets the browser handle other things
            await asyncio.sleep(0)

    # Clean up pygame when the whole app is done
    pygame.quit()


# ── Entry Point ────────────────────────────────────────────
# asyncio.run(main()) is the magic that starts the whole game!
# pygbag needs the async/await pattern to work in the browser.
asyncio.run(main())
```
