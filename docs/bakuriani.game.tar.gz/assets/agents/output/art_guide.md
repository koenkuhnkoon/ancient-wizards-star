# The Ancient Wizard's Star — Art Style Guide

---

## 1. Art Style Overview

The Ancient Wizard's Star uses a bold, cartoonish style directly inspired by Brawl Stars. Every character, monster, and object is drawn with a thick black outline (at least 2 pixels wide, scaled to sprite size) so shapes pop cleanly against any background. Colors are bright and saturated — think candy-colored magic, glowing shards, and vivid monster skins. Nothing should look washed out or realistic. The world feels playful and slightly silly, like a magical theme park where danger lurks around every corner. Shadows are kept simple: a single darker tone on one side of a shape, never detailed or photorealistic.

The camera looks straight down at the world (top-down view), so character designs emphasize the top of the head, shoulders, and arms. Heads are slightly oversized compared to bodies — about 40-50% of total sprite height — giving characters personality at a glance. Monsters lean into their "type" with exaggerated features: the zombie staggers with arms out, the poisonous mushroom is a vivid purple blob with a grumpy face, the stonehead turtle has a massive rocky shell. The final boss, the ninja land-eel, should look genuinely intimidating — long, electric-blue body with crackling yellow lightning lines and a samurai mask face.

---

## 2. Color Palette

### Primary Palette

| Name             | Hex Code    | Use Category          |
|------------------|-------------|-----------------------|
| Sky Blue         | `#5BC8F5`   | Background / sky tiles |
| Grass Green      | `#4CAF50`   | Background / ground tiles |
| Deep Earth       | `#7B5E3A`   | Background / dirt, paths |
| Stone Grey       | `#8B9DA8`   | Background / walls, rocks |
| Hero Gold        | `#F5C842`   | Character highlight, UI accent |
| Magic Purple     | `#9B59B6`   | Magic effects, wizard color |
| Danger Red       | `#E74C3C`   | Enemy color, health bar, damage flash |
| Energy Cyan      | `#00E5FF`   | Energy bar, magic projectiles |
| Shard Teal       | `#1ABC9C`   | Magical shards, collectibles |
| Outline Black    | `#1A1A1A`   | All sprite outlines |

### Categorized

- **Background colors:** `#5BC8F5`, `#4CAF50`, `#7B5E3A`, `#8B9DA8`
- **Character colors:** `#F5C842`, `#9B59B6`, `#1A1A1A` (outlines)
- **UI colors:** `#F5C842` (health bar fill), `#00E5FF` (energy bar fill), `#1A1A1A` (UI borders), `#FFFFFF` for text
- **Danger / enemy colors:** `#E74C3C`, `#6B2C2C` (dark red for boss), `#A8FF00` (poison green for mushroom)

### Avoid These

Do not use: muddy browns mixed with grey (`#7D7060`), muted pastels (`#B0C4DE`), near-black navy (`#0A0A2A`), or any color that reduces to grey on a small screen. Avoid using white as a character fill color — it disappears against bright backgrounds. Avoid pure `#000000` black for fills — use `#1A1A1A` for depth.

---

## 3. Sprite Size Specifications

All sizes are in pixels (width x height). Every sprite is drawn at these sizes and exported as PNG with a transparent background.

### Player Characters

| Character Class | Sprite Size (px) | Notes |
|-----------------|-----------------|-------|
| Wizard          | 48 x 48         | Tall pointed hat adds visual height |
| Knight          | 48 x 48         | Broad shoulders, heavy armor silhouette |
| Assassin        | 48 x 48         | Slim, crouched posture |
| Miner           | 48 x 48         | Stocky, holds pickaxe |
| Ninja           | 48 x 48         | Wrapped in dark cloth, agile stance |
| Robot           | 48 x 48         | Boxy body, glowing eyes |

### Enemy Monsters

| Monster Type        | Sprite Size (px) | Notes |
|---------------------|-----------------|-------|
| Evil Ninja          | 44 x 44         | Similar to player ninja but darker palette |
| Sewage Creature     | 52 x 44         | Wide, low blob shape, dripping edges |
| Zombie              | 44 x 48         | Slouched, arms forward |
| Land Octopus        | 56 x 44         | Wide — tentacles spread sideways |
| Little Devil        | 40 x 44         | Small but mean, tiny horns and tail |
| Skeleton            | 44 x 48         | Tall and thin, visible ribs |
| Poisonous Mushroom  | 40 x 40         | Round cap, grumpy face, small legs |
| Stonehead Turtle    | 56 x 48         | Wide rocky shell dominates sprite |

### Boss Characters

| Boss                  | Sprite Size (px) | Notes |
|-----------------------|-----------------|-------|
| Mini-Boss (generic)   | 64 x 64         | Each of the 6 mini-bosses uses this size |
| Ninja Land-Eel (Final)| 128 x 64        | Wide horizontal body, snake-like, electric effects |

### NPCs

| NPC Type     | Sprite Size (px) | Notes |
|--------------|-----------------|-------|
| Villager     | 44 x 44         | Friendly face, simple clothes |
| Shopkeeper   | 44 x 44         | Apron, counter prop drawn separately |
| Companion    | 48 x 48         | Same size as player class |

### Items

| Item Type           | Sprite Size (px) | Notes |
|---------------------|-----------------|-------|
| Magical Shard       | 16 x 16         | Gem-shaped, glowing teal outline |
| Sword               | 24 x 24         | Simple top-down blade view |
| Staff (Wizard)      | 24 x 24         | Orb at top glows |
| Pickaxe (Miner)     | 24 x 24         | Tool silhouette |
| Armor Piece (Chest) | 24 x 24         | Breastplate icon |
| Armor Piece (Helm)  | 24 x 24         | Helmet icon, top-down |
| Shop Item (generic) | 24 x 24         | Bright colored bag or box |

### World Tiles

All world tiles are 32 x 32 pixels and tile seamlessly edge-to-edge.

| Tile Type           | Sprite Size (px) | Notes |
|---------------------|-----------------|-------|
| Grass Ground        | 32 x 32         | Light green with subtle texture |
| Dirt Path           | 32 x 32         | Tan/brown, slightly worn look |
| Stone Floor         | 32 x 32         | Grey bricks pattern |
| Water               | 32 x 32         | Animated, 4 frames of ripple |
| Wall (solid)        | 32 x 32         | Darker stone, no entry |
| Ancient Portal Gate | 128 x 128       | Large, glowing purple archway, animated |
| Respawn Point       | 32 x 32         | Glowing circle on ground, friendly color |
| Tree (decoration)   | 32 x 48         | Top-down, round green circle top |

### Projectiles and Magic Effects

| Effect              | Sprite Size (px) | Notes |
|---------------------|-----------------|-------|
| Magic Bolt          | 16 x 16         | Round glowing orb |
| Lightning Bolt      | 32 x 16         | Jagged horizontal line, yellow |
| Sword Slash         | 32 x 32         | White arc shape, 3-frame animation |
| Poison Cloud        | 24 x 24         | Green swirl, 4-frame animation |
| Shard Pickup Flash  | 24 x 24         | Sparkle burst, 4-frame animation |
| Hit Flash           | 32 x 32         | White/red burst, 2-frame animation |
| Portal Glow         | 64 x 64         | Layered on top of portal tile |

### UI Elements

| Element             | Sprite Size (px) | Notes |
|---------------------|-----------------|-------|
| Health Bar (frame)  | 120 x 16        | Black outline frame |
| Health Bar (fill)   | 116 x 12        | Red fill, shrinks as health drops |
| Energy Bar (frame)  | 120 x 16        | Black outline frame |
| Energy Bar (fill)   | 116 x 12        | Cyan fill, shrinks as energy drops |
| Character Portrait  | 48 x 48         | Shows selected class face |
| Item Slot           | 32 x 32         | Square icon slot with border |
| Button (standard)   | 120 x 36        | Rounded rectangle, gold outline |
| Menu Panel          | 400 x 300       | Semi-transparent dark background |
| Minimap Frame       | 128 x 128       | Square, top-down world overview |
| Coin / Shard Count  | 24 x 24         | Icon + number next to it |

---

## 4. UI Layout Specifications

The HUD (heads-up display) sits along the edges of the 1280 x 720 screen, leaving the center clear for gameplay.

### Health Bar

- Position: top-left, starting at x=12, y=12
- Size: 120 x 16 pixels
- Outer frame color: `#1A1A1A` (black border, 2px thick)
- Fill color: `#E74C3C` (red, filled left to right based on current health)
- Background (empty bar): `#5A1A1A` (dark red to show depletion)
- Label: draw the word "HP" in white 10px font to the left of the bar

### Energy Bar

- Position: directly below health bar, starting at x=12, y=34
- Size: 120 x 16 pixels
- Outer frame color: `#1A1A1A`
- Fill color: `#00E5FF` (cyan)
- Background (empty bar): `#003A45` (dark cyan)
- Label: draw "EN" in white 10px font to the left of the bar

### Character Portrait

- Position: x=12, y=60
- Size: 48 x 48 pixels
- Shows the face/head of the current player character class
- Surrounded by a 2px `#F5C842` gold border

### Item Slots

- Position: bottom-center of screen
- 4 item slots in a horizontal row
- Each slot: 36 x 36 pixels with a 2px `#1A1A1A` border and `#2A2A2A` dark background
- Row starts at x=560, y=670 (centered on 1280px width)
- Spacing: 4px between each slot
- Total row width: (36 x 4) + (4 x 3) = 156px, centered at x=562

### Safe Zone (Gameplay Area)

- The game world is visible in: x=0 to x=1280, y=0 to y=720 (full screen)
- HUD elements in top-left corner cover approximately x=0-150, y=0-120
- Item slots cover approximately x=540-700, y=655-720
- Keep important game events (combat, pickups, boss fights) away from these regions
- Minimap (if used): top-right corner at x=1140, y=12, size 128 x 128

---

## 5. Animation Frame Guide

Keep all animations between 4 and 8 frames. At 60 FPS, plan for each frame to display for 6-10 game ticks (0.1-0.17 seconds per frame).

### Player Characters (all 6 classes follow this pattern)

| Animation  | Frame Count | Frame Descriptions |
|------------|-------------|-------------------|
| Idle       | 4           | F1: neutral; F2: slight lean forward; F3: neutral; F4: slight lean back (breathing loop) |
| Walk       | 6           | F1-F6: left foot, neutral, right foot, neutral, repeated — arms swing gently |
| Run        | 6           | F1-F6: same as walk but wider stance, more exaggerated lean forward |
| Attack     | 4           | F1: wind-up (arm/weapon pulled back); F2: full swing; F3: follow-through; F4: return to idle |
| Take Damage| 2           | F1: white flash / recoil backward; F2: return to idle |
| Defeat     | 4           | F1: stumble; F2: fall to knees; F3: flat on ground; F4: hold flat (loop last frame) |

### Enemy Monsters (all standard enemies follow this pattern)

| Animation  | Frame Count | Frame Descriptions |
|------------|-------------|-------------------|
| Idle       | 4           | Subtle bounce or sway specific to creature type |
| Walk       | 4           | Simple 4-frame shuffle toward player |
| Attack     | 4           | F1: wind-up; F2: strike; F3: recoil; F4: reset |
| Take Damage| 2           | F1: red tint flash; F2: back to normal |
| Defeat     | 4           | F1-F3: collapse or explode; F4: disappear (transparent) |

### Specific Monster Idles (unique touches)

| Monster             | Idle Behavior |
|---------------------|---------------|
| Evil Ninja          | Crouches lower on F2 and F4 — sneaking pulse |
| Sewage Creature     | Bubbles appear on F2 and F4 at edge of body |
| Zombie              | Slow sway left-right, head droops on F3 |
| Land Octopus        | One or two tentacles wave on F2 and F4 |
| Little Devil        | Wings flutter on F2 and F4 |
| Skeleton            | Jaw chatters on F3 and F4 |
| Poisonous Mushroom  | Cap bounces up on F2, settles on F4 |
| Stonehead Turtle    | Head retreats into shell on F3, peeks out on F4 |

### Boss: Ninja Land-Eel (Final Boss)

| Animation      | Frame Count | Frame Descriptions |
|----------------|-------------|-------------------|
| Idle           | 6           | Body undulates in an S-wave from head to tail, electric sparks on F3 and F6 |
| Move           | 6           | S-wave motion faster, body slides sideways |
| Sword Attack   | 6           | F1: raise sword; F2: charge (lightning crackles on blade); F3-F4: horizontal slash arc with electric bolt; F5: recoil; F6: reset |
| Electric Burst | 4           | F1-F4: electric ring expands outward from body center, fades on F4 |
| Take Damage    | 2           | F1: white flash; F2: normal |
| Defeat         | 8           | F1-F4: spasms with electric sparks; F5-F6: body dissolves; F7: bright flash; F8: empty |

### World Elements

| Element          | Frame Count | Frame Descriptions |
|------------------|-------------|-------------------|
| Water Tile       | 4           | Slow ripple: wave crest shifts position each frame |
| Ancient Portal   | 8           | Swirling purple vortex: 8-frame clockwise rotation of energy rings |
| Respawn Point    | 4           | Gentle pulse: glow expands and contracts |
| Shard (idle)     | 4           | Slow rotation and sparkle |

### Effects

| Effect         | Frame Count | Frame Descriptions |
|----------------|-------------|-------------------|
| Sword Slash    | 3           | F1: arc appears; F2: arc fades; F3: gone |
| Hit Flash      | 2           | F1: white-red burst; F2: gone |
| Poison Cloud   | 4           | F1: small; F2: expand; F3: drift; F4: fade |
| Shard Pickup   | 4           | F1-F3: sparkle burst expands; F4: gone |

---

## 6. Complete Asset Checklist

### player/

```
player_wizard_idle.png          — 48x48  — Wizard idle, 4 frames (spritesheet: 192x48)
player_wizard_walk.png          — 48x48  — Wizard walk, 6 frames (spritesheet: 288x48)
player_wizard_run.png           — 48x48  — Wizard run, 6 frames (spritesheet: 288x48)
player_wizard_attack.png        — 48x48  — Wizard attack, 4 frames (spritesheet: 192x48)
player_wizard_hurt.png          — 48x48  — Wizard take damage, 2 frames (spritesheet: 96x48)
player_wizard_defeat.png        — 48x48  — Wizard defeat, 4 frames (spritesheet: 192x48)
player_wizard_portrait.png      — 48x48  — Wizard face portrait for HUD

player_knight_idle.png          — 48x48  — Knight idle, 4 frames (spritesheet: 192x48)
player_knight_walk.png          — 48x48  — Knight walk, 6 frames (spritesheet: 288x48)
player_knight_run.png           — 48x48  — Knight run, 6 frames (spritesheet: 288x48)
player_knight_attack.png        — 48x48  — Knight attack, 4 frames (spritesheet: 192x48)
player_knight_hurt.png          — 48x48  — Knight take damage, 2 frames (spritesheet: 96x48)
player_knight_defeat.png        — 48x48  — Knight defeat, 4 frames (spritesheet: 192x48)
player_knight_portrait.png      — 48x48  — Knight face portrait for HUD

player_assassin_idle.png        — 48x48  — Assassin idle, 4 frames (spritesheet: 192x48)
player_assassin_walk.png        — 48x48  — Assassin walk, 6 frames (spritesheet: 288x48)
player_assassin_run.png         — 48x48  — Assassin run, 6 frames (spritesheet: 288x48)
player_assassin_attack.png      — 48x48  — Assassin attack, 4 frames (spritesheet: 192x48)
player_assassin_hurt.png        — 48x48  — Assassin take damage, 2 frames (spritesheet: 96x48)
player_assassin_defeat.png      — 48x48  — Assassin defeat, 4 frames (spritesheet: 192x48)
player_assassin_portrait.png    — 48x48  — Assassin face portrait for HUD

player_miner_idle.png           — 48x48  — Miner idle, 4 frames (spritesheet: 192x48)
player_miner_walk.png           — 48x48  — Miner walk, 6 frames (spritesheet: 288x48)
player_miner_run.png            — 48x48  — Miner run, 6 frames (spritesheet: 288x48)
player_miner_attack.png         — 48x48  — Miner attack, 4 frames (spritesheet: 192x48)
player_miner_hurt.png           — 48x48  — Miner take damage, 2 frames (spritesheet: 96x48)
player_miner_defeat.png         — 48x48  — Miner defeat, 4 frames (spritesheet: 192x48)
player_miner_portrait.png       — 48x48  — Miner face portrait for HUD

player_ninja_idle.png           — 48x48  — Ninja idle, 4 frames (spritesheet: 192x48)
player_ninja_walk.png           — 48x48  — Ninja walk, 6 frames (spritesheet: 288x48)
player_ninja_run.png            — 48x48  — Ninja run, 6 frames (spritesheet: 288x48)
player_ninja_attack.png         — 48x48  — Ninja attack, 4 frames (spritesheet: 192x48)
player_ninja_hurt.png           — 48x48  — Ninja take damage, 2 frames (spritesheet: 96x48)
player_ninja_defeat.png         — 48x48  — Ninja defeat, 4 frames (spritesheet: 192x48)
player_ninja_portrait.png       — 48x48  — Ninja face portrait for HUD

player_robot_idle.png           — 48x48  — Robot idle, 4 frames (spritesheet: 192x48)
player_robot_walk.png           — 48x48  — Robot walk, 6 frames (spritesheet: 288x48)
player_robot_run.png            — 48x48  — Robot run, 6 frames (spritesheet: 288x48)
player_robot_attack.png         — 48x48  — Robot attack, 4 frames (spritesheet: 192x48)
player_robot_hurt.png           — 48x48  — Robot take damage, 2 frames (spritesheet: 96x48)
player_robot_defeat.png         — 48x48  — Robot defeat, 4 frames (spritesheet: 192x48)
player_robot_portrait.png       — 48x48  — Robot face portrait for HUD
```

### enemies/

```
enemy_evil_ninja_idle.png           — 44x44  — Evil ninja idle, 4 frames (spritesheet: 176x44)
enemy_evil_ninja_walk.png           — 44x44  — Evil ninja walk, 4 frames (spritesheet: 176x44)
enemy_evil_ninja_attack.png         — 44x44  — Evil ninja attack, 4 frames (spritesheet: 176x44)
enemy_evil_ninja_hurt.png           — 44x44  — Evil ninja hurt, 2 frames (spritesheet: 88x44)
enemy_evil_ninja_defeat.png         — 44x44  — Evil ninja defeat, 4 frames (spritesheet: 176x44)

enemy_sewage_creature_idle.png      — 52x44  — Sewage creature idle, 4 frames (spritesheet: 208x44)
enemy_sewage_creature_walk.png      — 52x44  — Sewage creature walk, 4 frames (spritesheet: 208x44)
enemy_sewage_creature_attack.png    — 52x44  — Sewage creature attack, 4 frames (spritesheet: 208x44)
enemy_sewage_creature_hurt.png      — 52x44  — Sewage creature hurt, 2 frames (spritesheet: 104x44)
enemy_sewage_creature_defeat.png    — 52x44  — Sewage creature defeat, 4 frames (spritesheet: 208x44)

enemy_zombie_idle.png               — 44x48  — Zombie idle, 4 frames (spritesheet: 176x48)
enemy_zombie_walk.png               — 44x48  — Zombie walk, 4 frames (spritesheet: 176x48)
enemy_zombie_attack.png             — 44x48  — Zombie attack, 4 frames (spritesheet: 176x48)
enemy_zombie_hurt.png               — 44x48  — Zombie hurt, 2 frames (spritesheet: 88x48)
enemy_zombie_defeat.png             — 44x48  — Zombie defeat, 4 frames (spritesheet: 176x48)

enemy_land_octopus_idle.png         — 56x44  — Land octopus idle, 4 frames (spritesheet: 224x44)
enemy_land_octopus_walk.png         — 56x44  — Land octopus walk, 4 frames (spritesheet: 224x44)
enemy_land_octopus_attack.png       — 56x44  — Land octopus attack, 4 frames (spritesheet: 224x44)
enemy_land_octopus_hurt.png         — 56x44  — Land octopus hurt, 2 frames (spritesheet: 112x44)
enemy_land_octopus_defeat.png       — 56x44  — Land octopus defeat, 4 frames (spritesheet: 224x44)

enemy_little_devil_idle.png         — 40x44  — Little devil idle, 4 frames (spritesheet: 160x44)
enemy_little_devil_walk.png         — 40x44  — Little devil walk, 4 frames (spritesheet: 160x44)
enemy_little_devil_attack.png       — 40x44  — Little devil attack, 4 frames (spritesheet: 160x44)
enemy_little_devil_hurt.png         — 40x44  — Little devil hurt, 2 frames (spritesheet: 80x44)
enemy_little_devil_defeat.png       — 40x44  — Little devil defeat, 4 frames (spritesheet: 160x44)

enemy_skeleton_idle.png             — 44x48  — Skeleton idle, 4 frames (spritesheet: 176x48)
enemy_skeleton_walk.png             — 44x48  — Skeleton walk, 4 frames (spritesheet: 176x48)
enemy_skeleton_attack.png           — 44x48  — Skeleton attack, 4 frames (spritesheet: 176x48)
enemy_skeleton_hurt.png             — 44x48  — Skeleton hurt, 2 frames (spritesheet: 88x48)
enemy_skeleton_defeat.png           — 44x48  — Skeleton defeat, 4 frames (spritesheet: 176x48)

enemy_poisonous_mushroom_idle.png   — 40x40  — Mushroom idle, 4 frames (spritesheet: 160x40)
enemy_poisonous_mushroom_walk.png   — 40x40  — Mushroom walk, 4 frames (spritesheet: 160x40)
enemy_poisonous_mushroom_attack.png — 40x40  — Mushroom attack, 4 frames (spritesheet: 160x40)
enemy_poisonous_mushroom_hurt.png   — 40x40  — Mushroom hurt, 2 frames (spritesheet: 80x40)
enemy_poisonous_mushroom_defeat.png — 40x40  — Mushroom defeat, 4 frames (spritesheet: 160x40)

enemy_stonehead_turtle_idle.png     — 56x48  — Stonehead turtle idle, 4 frames (spritesheet: 224x48)
enemy_stonehead_turtle_walk.png     — 56x48  — Stonehead turtle walk, 4 frames (spritesheet: 224x48)
enemy_stonehead_turtle_attack.png   — 56x48  — Stonehead turtle attack, 4 frames (spritesheet: 224x48)
enemy_stonehead_turtle_hurt.png     — 56x48  — Stonehead turtle hurt, 2 frames (spritesheet: 112x48)
enemy_stonehead_turtle_defeat.png   — 56x48  — Stonehead turtle defeat, 4 frames (spritesheet: 224x48)

boss_miniboss_idle.png              — 64x64  — Generic mini-boss idle, 4 frames (spritesheet: 256x64)
boss_miniboss_walk.png              — 64x64  — Generic mini-boss walk, 4 frames (spritesheet: 256x64)
boss_miniboss_attack.png            — 64x64  — Generic mini-boss attack, 4 frames (spritesheet: 256x64)
boss_miniboss_hurt.png              — 64x64  — Generic mini-boss hurt, 2 frames (spritesheet: 128x64)
boss_miniboss_defeat.png            — 64x64  — Generic mini-boss defeat, 4 frames (spritesheet: 256x64)

boss_ninja_land_eel_idle.png        — 128x64 — Final boss idle, 6 frames (spritesheet: 768x64)
boss_ninja_land_eel_move.png        — 128x64 — Final boss move, 6 frames (spritesheet: 768x64)
boss_ninja_land_eel_attack.png      — 128x64 — Final boss sword attack, 6 frames (spritesheet: 768x64)
boss_ninja_land_eel_electric.png    — 128x64 — Final boss electric burst, 4 frames (spritesheet: 512x64)
boss_ninja_land_eel_hurt.png        — 128x64 — Final boss hurt, 2 frames (spritesheet: 256x64)
boss_ninja_land_eel_defeat.png      — 128x64 — Final boss defeat, 8 frames (spritesheet: 1024x64)
```

### npc/

```
npc_villager_idle.png               — 44x44  — Villager idle, 4 frames (spritesheet: 176x44)
npc_villager_walk.png               — 44x44  — Villager walk, 4 frames (spritesheet: 176x44)
npc_shopkeeper_idle.png             — 44x44  — Shopkeeper idle, 4 frames (spritesheet: 176x44)
npc_companion_wizard_idle.png       — 48x48  — Companion wizard idle, 4 frames (spritesheet: 192x48)
npc_companion_wizard_walk.png       — 48x48  — Companion wizard walk, 6 frames (spritesheet: 288x48)
npc_companion_wizard_attack.png     — 48x48  — Companion wizard attack, 4 frames (spritesheet: 192x48)
npc_companion_knight_idle.png       — 48x48  — Companion knight idle, 4 frames (spritesheet: 192x48)
npc_companion_knight_walk.png       — 48x48  — Companion knight walk, 6 frames (spritesheet: 288x48)
npc_companion_knight_attack.png     — 48x48  — Companion knight attack, 4 frames (spritesheet: 192x48)
```

### items/

```
item_magical_shard.png              — 16x16  — Magical shard collectible, 4-frame spin (spritesheet: 64x16)
item_sword.png                      — 24x24  — Basic sword, single frame icon
item_staff_wizard.png               — 24x24  — Wizard staff, single frame icon
item_pickaxe_miner.png              — 24x24  — Miner pickaxe, single frame icon
item_armor_chest.png                — 24x24  — Chest armor icon, single frame
item_armor_helm.png                 — 24x24  — Helmet icon, single frame
item_shop_bag.png                   — 24x24  — Generic shop item bag icon
```

### world/

```
tile_grass.png                      — 32x32  — Grass ground tile, seamless
tile_dirt.png                       — 32x32  — Dirt path tile, seamless
tile_stone_floor.png                — 32x32  — Stone floor tile, seamless
tile_water.png                      — 32x32  — Water tile, 4-frame ripple (spritesheet: 128x32)
tile_wall.png                       — 32x32  — Solid stone wall tile
tile_tree.png                       — 32x48  — Tree decoration, single frame
world_respawn_point.png             — 32x32  — Respawn point glow, 4 frames (spritesheet: 128x32)
world_portal_gate.png               — 128x128 — Ancient Dimensional Portal Gate, 8-frame swirl (spritesheet: 1024x128)
world_portal_glow.png               — 64x64  — Layered portal glow effect, 8 frames (spritesheet: 512x64)
```

### effects/

```
effect_magic_bolt.png               — 16x16  — Magic bolt projectile, 4 frames (spritesheet: 64x16)
effect_lightning_bolt.png           — 32x16  — Lightning bolt projectile, 4 frames (spritesheet: 128x16)
effect_sword_slash.png              — 32x32  — Sword slash arc, 3 frames (spritesheet: 96x32)
effect_poison_cloud.png             — 24x24  — Poison cloud puff, 4 frames (spritesheet: 96x24)
effect_shard_pickup.png             — 24x24  — Shard pickup sparkle burst, 4 frames (spritesheet: 96x24)
effect_hit_flash.png                — 32x32  — Hit impact flash, 2 frames (spritesheet: 64x32)
effect_electric_ring.png            — 64x64  — Electric ring burst (boss), 4 frames (spritesheet: 256x64)
```

### ui/

```
ui_health_bar_frame.png             — 120x16 — Health bar outer frame, black border
ui_health_bar_fill.png              — 116x12 — Health bar red fill, scales with current HP
ui_energy_bar_frame.png             — 120x16 — Energy bar outer frame, black border
ui_energy_bar_fill.png              — 116x12 — Energy bar cyan fill, scales with current energy
ui_item_slot.png                    — 36x36  — Empty item slot icon
ui_item_slot_selected.png           — 36x36  — Selected item slot with gold highlight border
ui_button_normal.png                — 120x36 — Standard menu button, gold outline
ui_button_hover.png                 — 120x36 — Menu button, brighter gold on hover
ui_menu_panel.png                   — 400x300 — Semi-transparent dark menu background panel
ui_minimap_frame.png                — 128x128 — Minimap border frame
ui_coin_icon.png                    — 24x24  — Coin/shard count icon for HUD display
ui_character_select_panel.png       — 600x400 — Character selection screen background panel
ui_title_screen_bg.png              — 1280x720 — Full title screen background image
```

---

*Art guide created by the Graphic Designer — review with Koen before making sprites!*
