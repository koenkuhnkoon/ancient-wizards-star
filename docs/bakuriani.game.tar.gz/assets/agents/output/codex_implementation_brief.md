# Codex Implementation Brief — The Ancient Wizard's Star: Boss Fight Upgrade

You are implementing new features for a Python/Pygame top-down RPG called **The Ancient Wizard's Star**. The codebase is simple and written for an 8-year-old to read, so keep all code well-commented and clearly named. No cryptic variable names.

**Read every file fully before modifying it. Write the complete file back — do not use partial patches.**

---

## Project structure

```
main.py                  ← main game loop, ~1270 lines
game/enemies.py          ← all enemy classes
game/npc.py              ← NPC classes (Villager, CompanionKnight, CompanionWizard)
game/world.py            ← World class (tile map drawing)
assets/                  ← PNG sprites (fall back gracefully if missing)
assets/sounds/           ← WAV/OGG sound files
```

Screen: 1280×704 px. Target: 60 FPS. Pygame coordinate system: (0,0) = top-left.

---

## What is already done (do NOT redo these)

- `game/enemies.py` already has `BOSS_ATTACK_DAMAGE = 3`, `BOSS_ATTACK_RANGE = 60`, per-instance `self.attack_damage`, `self.attack_range`, and `self.just_attacked` flag on the `Enemy` base class.
- `main.py` already has a red `AttackEffect` spawned at the player when `enemy.just_attacked` or `boss.just_attacked` is True.
- `Voltrak` class already exists in `game/enemies.py` with a cross-shaped electric shock mechanic (`shock_zones`, `shock_just_fired`, `draw_shocks()`).
- Voltrak is already spawned and updated in `main.py` with shock collision checking.

---

## What to implement

### 1 — Enemy animation state machine (`game/enemies.py`)

Add walk + attack animation support to the `Enemy` base class.

**New constants** (add near top of file with other constants):
```python
ENEMY_ANIM_IDLE_SPEED   = 14   # frames between animation frame advances while wandering
ENEMY_ANIM_WALK_SPEED   =  8   # frames between advances while chasing
ENEMY_ANIM_ATTACK_SPEED =  5   # frames between advances during attack animation
ENEMY_ATTACK_ANIM_TICKS = 12   # how many frames to hold the attack animation
```

**New helper function** (add after `_load_sprite()`):
```python
def _load_enemy_animations(base_name, w, h, fallback_sprite):
    """Try to load walk and attack sprite sheets for an enemy.

    Looks for:
      assets/BASE_walk.png   — horizontal strip, 4 frames of w×h px
      assets/BASE_attack.png — horizontal strip, 4 frames of w×h px

    If either file is missing, falls back to a 1-frame list containing
    the existing fallback_sprite so the game still works without art.

    Returns: {"idle": [sprite], "walk": [...], "attack": [...]}
    """
```

Pass the full filename prefix, e.g. `"enemy_evil_ninja"` → looks for `enemy_evil_ninja_walk.png`.
Slice frames using `sheet.subsurface(pygame.Rect(i * w, 0, w, h))`.

**New fields in `Enemy.__init__()`** (add alongside existing fields):
```python
self.animations        = {}      # filled by subclass; empty = use static self.sprite
self.anim_state        = "idle"  # "idle", "walk", or "attack"
self.anim_frame        = 0       # current frame index into animations[anim_state]
self.anim_tick         = 0       # counts up; advance frame when it hits the speed threshold
self.attack_anim_ticks = 0       # counts down after an attack so we hold the attack pose
```

**State transitions in `Enemy.update()`**:
- `STATE_WANDER` → `self.anim_state = "idle"`
- `STATE_CHASE`  → `self.anim_state = "walk"`
- When `self.just_attacked` becomes True → `self.anim_state = "attack"` and `self.attack_anim_ticks = ENEMY_ATTACK_ANIM_TICKS`
- Decrement `attack_anim_ticks` each frame; when it reaches 0, set `anim_state` back to `"walk"` or `"idle"` to match current movement state

**New helper method `_advance_animation()`** (call at the end of `update()`):
```python
def _advance_animation(self):
    """Step the animation forward by one frame if enough ticks have passed."""
    speed_map = {
        "idle":   ENEMY_ANIM_IDLE_SPEED,
        "walk":   ENEMY_ANIM_WALK_SPEED,
        "attack": ENEMY_ANIM_ATTACK_SPEED,
    }
    speed = speed_map.get(self.anim_state, ENEMY_ANIM_WALK_SPEED)
    self.anim_tick += 1
    if self.anim_tick >= speed:
        self.anim_tick = 0
        frames = self.animations.get(self.anim_state, [])
        if frames:
            self.anim_frame = (self.anim_frame + 1) % len(frames)
```

**Updated `Enemy.draw()`** — replace `screen.blit(self.sprite, ...)` with:
```python
frames = self.animations.get(self.anim_state, [])
frame  = frames[self.anim_frame] if frames else self.sprite   # fallback = static sprite
screen.blit(frame, (self.x, self.y))
```

**Each concrete enemy subclass** (`EvilNinja`, `Skeleton`, `Zombie`, `Grimrak`, `Zara`) should call `_load_enemy_animations()` in `__init__` and store the result in `self.animations`. Example for `EvilNinja` (44×44):
```python
self.animations = _load_enemy_animations("enemy_evil_ninja", 44, 44, sprite)
```

---

### 2 — Grimrak special attack: ground slam (`game/enemies.py`)

**New fields in `Grimrak.__init__()`**:
```python
self.slam_cooldown = 300   # 5 seconds at 60 FPS; counts down to 0 then slams
self.slam_active   = 0     # counts down from 20 when a slam is happening (0.33 s)
```

**New `Grimrak.update(player)`** (call `super().update(player)` first, then add):
```python
if self.state == STATE_DEAD:
    return
if self.state == STATE_CHASE:
    self.slam_cooldown -= 1
    if self.slam_cooldown <= 0:
        self.slam_cooldown = 300
        self.slam_active   = 20
if self.slam_active > 0:
    self.slam_active -= 1
```

**In `main.py`** — add slam damage check after the miniboss update loop:
```python
# Grimrak ground slam — deals 3 HP if the player is in the orange zone
for boss in miniboss_list:
    if hasattr(boss, 'slam_active') and boss.slam_active > 0:
        slam_rect   = pygame.Rect(boss.x - 25, boss.y - 25, 130, 130)
        player_rect = pygame.Rect(player.x, player.y,
                                  player.sprite_width, player.sprite_height)
        if slam_rect.colliderect(player_rect):
            player.take_damage(3)
            sounds.play_hurt()
```

**In `main.py`** — draw the slam zone (in the draw section, between bosses and companions):
```python
for boss in miniboss_list:
    if hasattr(boss, 'slam_active') and boss.slam_active > 0:
        slam_surf = pygame.Surface((130, 130), pygame.SRCALPHA)
        alpha = int(160 * boss.slam_active / 20)   # fades out as timer decreases
        slam_surf.fill((255, 140, 0, alpha))        # orange, semi-transparent
        screen.blit(slam_surf, (boss.x - 25, boss.y - 25))
```

---

### 3 — Enemy projectile class + Zara magic bolt (`game/enemies.py`)

**New `EnemyProjectile` class** (add before `Grimrak`):
```python
class EnemyProjectile:
    """A projectile fired by an enemy toward the player.

    Travels in a straight line until it hits the player or goes too far.
    Drawn as a filled circle (no sprite required — keeps it simple!).
    """
    def __init__(self, x, y, target_x, target_y, speed, damage, color, max_travel=500):
        self.x          = x
        self.y          = y
        self.damage     = damage
        self.color      = color      # (R, G, B)
        self.radius     = 8
        self.alive      = True
        self.traveled   = 0
        self.max_travel = max_travel
        # Unit vector pointing from the firing position toward the target
        dx   = target_x - x
        dy   = target_y - y
        dist = math.sqrt(dx * dx + dy * dy) or 1
        self.dx = dx / dist * speed
        self.dy = dy / dist * speed

    def update(self):
        self.x        += self.dx
        self.y        += self.dy
        self.traveled += math.sqrt(self.dx ** 2 + self.dy ** 2)
        if self.traveled >= self.max_travel:
            self.alive = False

    def get_rect(self):
        return pygame.Rect(int(self.x) - self.radius, int(self.y) - self.radius,
                           self.radius * 2, self.radius * 2)

    def draw(self, screen):
        if self.alive:
            pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), self.radius)
```

**New fields in `Zara.__init__()`**:
```python
self.bolt_cooldown       = 180   # 3 seconds; counts down to 0 then fires
self.pending_projectiles = []    # handed off to main.py each frame
```

**New `Zara.update(player)`** (call `super().update(player)` first, then add):
```python
self.pending_projectiles = []   # reset each frame
if self.state == STATE_DEAD:
    return
if self.state == STATE_CHASE:
    self.bolt_cooldown -= 1
    if self.bolt_cooldown <= 0:
        self.bolt_cooldown = 180
        cx, cy = self.get_center()
        px, py = player.x + 24, player.y + 24
        self.pending_projectiles.append(
            EnemyProjectile(cx, cy, px, py,
                            speed=6, damage=2, color=(180, 0, 255))
        )
```

**In `main.py`** — add `enemy_proj_list = []` near the top of `main()` alongside other lists.

After the miniboss update loop, collect + move projectiles:
```python
# Collect any new projectiles Zara (or future bosses) just fired
for boss in miniboss_list:
    if hasattr(boss, 'pending_projectiles'):
        enemy_proj_list.extend(boss.pending_projectiles)

# Move projectiles and check if they hit the player
player_rect = pygame.Rect(player.x, player.y,
                           player.sprite_width, player.sprite_height)
for proj in enemy_proj_list[:]:
    proj.update()
    if not proj.alive:
        enemy_proj_list.remove(proj)
        continue
    if proj.get_rect().colliderect(player_rect):
        player.take_damage(proj.damage)
        sounds.play_hurt()
        proj.alive = False
        enemy_proj_list.remove(proj)
```

In the draw section (between boss layer and companion layer):
```python
for proj in enemy_proj_list:
    proj.draw(screen)
```

---

### 4 — Summoner NPC (`game/npc.py`)

**New `SummonerNPC` class** (add after `Villager`):
```python
class SummonerNPC(Villager):
    """A friendly wizard who summons companion fighters for the player.

    Phase 1: can summon 1 CompanionFighter (during mini-boss phase).
    Phase 2: unlocked after both mini-bosses are defeated — can summon a
             second fighter AND pre-activate 2 companions for the Voltrak arena.

    The player interacts by walking close and pressing E.
    main.py calls on_interact() when E is pressed.
    """
    def __init__(self, x, y):
        super().__init__(x, y, "Press [E] to summon a companion fighter!")
        self.sprite = _load_sprite("npc_summoner.png", 44, 44, (200, 160, 0))
        self.phase                  = 1      # 1 = mini-boss phase, 2 = both beaten
        self.companions_summoned    = 0
        self.pre_activated_voltrak  = False

    def notify_bosses_beaten(self):
        """Call from main.py when both mini-bosses are defeated."""
        self.phase     = 2
        self.hint_text = "Two heroes will fight with you through the portal! Press [E] to activate."

    def can_summon(self):
        return self.companions_summoned < self.phase

    def on_interact(self):
        """Called by main.py when the player presses E nearby.

        Returns:
            "summon"       — spawn a CompanionFighter at the player's position
            "pre_activate" — store that 2 companions will enter the portal
            None           — nothing to do right now
        """
        if self.phase == 2 and not self.pre_activated_voltrak:
            self.pre_activated_voltrak = True
            self.hint_text = "Two companions await you through the portal — go!"
            return "pre_activate"
        if self.can_summon():
            self.companions_summoned += 1
            return "summon"
        return None
```

**Update `create_npc_group()`**: add `summoner = SummonerNPC(640, 500)` and return it as a third value: `return companions, villagers, summoner`.

**In `main.py`**: unpack the third return value from `create_npc_group()`. Add summoner to the draw loop. In the E-key handler, check distance to summoner (< 80 px) and call `summoner.on_interact()`, acting on the result.

---

### 5 — CompanionFighter (`game/npc.py`)

A companion that actively attacks nearby enemies.

**New constants** (top of `game/npc.py`):
```python
FIGHTER_SPEED        = 3
FIGHTER_ATTACK_RANGE = 45
FIGHTER_DAMAGE       = 2
FIGHTER_COOLDOWN     = 90
```

**New `CompanionFighter` class** (add after `CompanionWizard`):
```python
class CompanionFighter(NPC):
    """A summoned companion who actively attacks enemies!

    Unlike CompanionKnight/CompanionWizard who just follow the player,
    CompanionFighter finds the nearest alive enemy and fights it.
    Falls back to following the player when no enemies are nearby.
    """
    def __init__(self, x, y):
        sprite = _load_sprite("npc_companion_knight.png", 48, 48, (255, 200, 50))
        super().__init__(x, y, sprite)
        self.attack_cooldown = 0

    def update(self, player, enemy_list, boss_list):
        """Find the nearest alive enemy or boss and attack or chase it."""
        targets = [e for e in enemy_list  if not e.is_dead()]
        targets += [b for b in boss_list if not b.is_permanently_dead()]

        if not targets:
            self._follow(player)
        else:
            my_cx, my_cy = self.get_center()
            nearest = min(targets,
                          key=lambda t: math.hypot(
                              t.x + t.sprite_width  // 2 - my_cx,
                              t.y + t.sprite_height // 2 - my_cy))
            dist = math.hypot(nearest.x + nearest.sprite_width  // 2 - my_cx,
                              nearest.y + nearest.sprite_height // 2 - my_cy)

            if dist <= FIGHTER_ATTACK_RANGE and self.attack_cooldown <= 0:
                nearest.take_damage(FIGHTER_DAMAGE)
                self.attack_cooldown = FIGHTER_COOLDOWN
            elif dist > FIGHTER_ATTACK_RANGE:
                dx = nearest.x + nearest.sprite_width  // 2 - my_cx
                dy = nearest.y + nearest.sprite_height // 2 - my_cy
                d  = math.hypot(dx, dy) or 1
                self.x += int(dx / d * FIGHTER_SPEED)
                self.y += int(dy / d * FIGHTER_SPEED)

        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1

        # Keep inside screen
        self.x = max(0, min(self.x, 1280 - self.sprite_width))
        self.y = max(0, min(self.y, 704  - self.sprite_height))

    def _follow(self, player):
        dist = self._distance_to_player(player)
        if dist > 80:
            px, py = player.x + 24, player.y + 24
            cx, cy = self.get_center()
            d = dist or 1
            self.x += int((px - cx) / d * FIGHTER_SPEED)
            self.y += int((py - cy) / d * FIGHTER_SPEED)
```

**In `main.py`**: add `fighter_companions = []`. Update them each frame with `fc.update(player, enemy_list, miniboss_list + voltrak_list)`. Draw them in the companion layer. When summoner returns `"summon"`, append a `CompanionFighter` near the player.

---

### 6 — Voltrak Arena World (`game/world.py`)

Add a `VoltrakArena` class alongside the existing `World` class, with the same `draw(screen)` and `update()` interface.

**New tile constants**:
```python
TILE_STONE    = 5   # dark stone floor for the arena interior
TILE_ELECTRIC = 6   # animated danger pit in the corners
```

**Map layout** (40 columns × 22 rows):
- All perimeter cells → `TILE_WALL`
- Interior cells → `TILE_STONE`
- Corners (rows 1–3 and 18–20, cols 1–3 and 37–39) → `TILE_ELECTRIC`

**`VoltrakArena.__init__()`**: build the grid, load tile sprites (`tile_wall.png`, `tile_stone.png` for floor, `tile_electric.png` for danger pits). Animate electric tiles the same way `World` animates water (4-frame strip, advance every 8 game ticks).

**`VoltrakArena.update()`**: advance the electric tile animation frame counter.

**`VoltrakArena.draw(screen)`**: iterate the grid and blit the correct tile surface (use the animated frame for `TILE_ELECTRIC`).

---

### 7 — Portal transition + victory screen (`main.py`)

**New state variables** (add near the top of `main()` alongside `portal_open`, `voltrak`, etc.):
```python
arena_mode            = False
voltrak_list          = []      # list containing Voltrak when in arena mode
fighter_companions    = []      # CompanionFighters summoned by the player
enemy_proj_list       = []      # projectiles fired by enemies
```

**Replace the "coming soon" portal overlay** (the block that currently shows `"(Final boss battle — coming soon!)"`) with a real arena transition. Trigger it when the player presses E near the portal gate while holding the portal key:

```python
# Enter Voltrak's arena!
arena_mode = True
world      = VoltrakArena()
player.x, player.y = 600, 330   # arena centre
# 2 fighters if pre-activated at the Summoner, otherwise 1
if summoner.pre_activated_voltrak:
    fighter_companions.append(CompanionFighter(480, 300))
    fighter_companions.append(CompanionFighter(720, 300))
else:
    fighter_companions.append(CompanionFighter(560, 300))
# Voltrak spawns in the middle of the arena
if not voltrak_list:
    from game.enemies import Voltrak
    voltrak_list.append(Voltrak(550, 280))
enemy_list.clear()
miniboss_list.clear()
item_list.clear()
```

**In the game loop update section** (when `arena_mode` is True), update `voltrak_list` and `fighter_companions` the same way `miniboss_list` and `companions` are updated.

**Victory condition**: when `voltrak_list` is non-empty and `voltrak_list[0].is_permanently_dead()`, set a `voltrak_defeated = True` flag and show the victory screen.

**New `draw_victory_screen(screen, font)` function** (mirror the existing `draw_death_screen()` pattern):
- Dark gold semi-transparent overlay
- Large text: `"YOU SAVED LUMORIA!"`
- Subtitle: `"Voltrak the Shockblade Eel has been defeated!"`
- Hint: `"Press Space to return to the menu"`

---

## Key rules for this codebase

1. **Read the full file, then write the complete file back** — no partial patches
2. All code must have simple English comments — an 8-year-old may be reading this
3. No single-letter variable names (except loop counters `i`, `j`)
4. If a PNG asset is missing, fall back to a coloured placeholder — **never crash**
5. Target 60 FPS — avoid creating new `pygame.Surface` objects inside the draw loop; pre-create them where possible
6. Keep the existing code structure — do not reorganise files or rename existing classes
