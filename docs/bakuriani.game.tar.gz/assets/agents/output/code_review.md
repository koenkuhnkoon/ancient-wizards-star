# QA Review — Wave 4

## Overall Result: PASS WITH NOTES

---

## Issues Found

### HIGH (must fix before applying to game/)

**1. [game_enemies.py] — `just_died` flag is never reset while the enemy is in STATE_DEAD, causing hundreds of shard drops**

In `Enemy.update()`:
```python
def update(self, player):
    if self.state == STATE_DEAD:
        self.respawn_ticks += 1
        if self.respawn_ticks >= RESPAWN_TICKS:
            self._respawn()
        return          # <-- early return here

    # Reset the just_died flag every frame (it should only be True for one frame)
    self.just_died = False   # <-- this line is SKIPPED every frame the enemy is dead!
```

`_die()` sets `just_died = True` and switches state to `STATE_DEAD`. From that point on,
every call to `update()` hits the early return before reaching `self.just_died = False`.
`_respawn()` does not reset it either. So `just_died` stays `True` for the entire
10-second (600-frame) respawn window.

In `main.py`, the shard-drop check runs every frame:
```python
for enemy in enemy_list:
    enemy.update(player)
    if enemy.just_died:
        item_list.append(MagicalShard(enemy.x, enemy.y))
```

**Result:** Every enemy death creates 600 shards instead of 1.

**Fix:** Move `self.just_died = False` to the very first line of `update()`, before any
state check, so it is reset unconditionally every frame:
```python
def update(self, player):
    self.just_died = False   # reset FIRST, every frame, always

    if self.state == STATE_DEAD:
        ...
```

**2. [game_main.py] — `ATTACK_DAMAGE` imported inside the game loop on every attack frame**

Deep inside the `if player.attacking:` block:
```python
from game.player import ATTACK_DAMAGE
enemy.take_damage(ATTACK_DAMAGE)
```

This `from game.player import ATTACK_DAMAGE` statement is inside the inner game loop.
Python caches modules so it will not reload the file, but it still performs a lookup in
`sys.modules` on every frame that `player.attacking` is True. More importantly, a reader
scanning the top of `main.py` to understand what it depends on will miss this import
entirely, which is confusing.

**Fix:** Move the import to the top of `main.py` alongside the other `game.player` import:
```python
from game.player import Player, ATTACK_DAMAGE
```

**3. [game_main.py] — Two `pygame.Surface` objects allocated inside `draw_pause_overlay()` which is called every frame while paused**

Inside `draw_pause_overlay()`:
```python
dim_surface   = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
panel_surface = pygame.Surface((PAUSE_PANEL_WIDTH, PAUSE_PANEL_HEIGHT), pygame.SRCALPHA)
```

These surfaces are created fresh on every call, and `draw_pause_overlay()` is called every
frame while the game is paused. `pygame.Surface` allocation is not free — it allocates
pixel memory each time. At 60 FPS this discards and recreates 120 surfaces per second.

The rest of `main.py` is careful to create surfaces and fonts once (e.g. `npc_font`
created once in `main()`). These two surfaces should follow the same rule.

**Fix:** Create both surfaces once in `main()` and pass them into `draw_pause_overlay()`:
```python
dim_surface   = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
panel_surface = pygame.Surface((PAUSE_PANEL_WIDTH, PAUSE_PANEL_HEIGHT), pygame.SRCALPHA)
```
Then update the function signature:
```python
def draw_pause_overlay(screen, pause_fonts, audio_enabled, selected_setting_index,
                       dim_surface, panel_surface):
```

---

### LOW (nice to fix, not blocking)

**4. [game_enemies.py] — Hard-coded `1280` and `720` in `_do_wander()` boundary clamp**

```python
self.x = max(0, min(self.x, 1280 - self.sprite_width))
self.y = max(0, min(self.y, 720 - self.sprite_height))
```

A comment explains these match `SCREEN_WIDTH`/`SCREEN_HEIGHT` in `main.py`, but magic
numbers inside a file that does not import from `main.py` are fragile. If the window is
ever resized, enemies would wander incorrectly without any obvious error.

**Suggested fix:** Add small constants at the top of `enemies.py`:
```python
SCREEN_WIDTH  = 1280   # should match main.py — update both if the window changes!
SCREEN_HEIGHT =  720
```

**5. [game_npc.py] — `_draw_bubble()` calls `font.render()` every frame the bubble is visible**

```python
def _draw_bubble(self, screen, font, text):
    text_surface = font.render(text, True, BUBBLE_TEXT_COLOR)
```

The hint text never changes, so `font.render()` is called up to 300 consecutive frames
drawing the exact same result each time. `font.render()` is one of the slower Pygame calls.

**Suggested fix:** Cache the rendered surface in `__init__()`:
```python
self.hint_surface = None   # will be set the first time draw is called
```
Then in `_draw_bubble()` render only once:
```python
if self.hint_surface is None:
    self.hint_surface = font.render(text, True, BUBBLE_TEXT_COLOR)
text_surface = self.hint_surface
```

**6. [game_main.py] — Shard counter text surface rendered in the draw loop every frame**

```python
shard_text = hud_font.render(f"Shards: {shards_collected}", True, (26, 188, 156))
```

`font.render()` is called 60 times per second even when `shards_collected` has not changed.
This is a minor inconsistency with the documented pattern of creating objects once. The
performance impact of one small string is negligible, but it sets an inconsistent example
for the codebase.

**7. [game_player.py] — `label_font` created in `Player.__init__()` instead of in `main()`**

```python
self.label_font = pygame.font.SysFont("Arial", 12)
```

Every other font in the project is created once in `main()` immediately after `pygame.init()`.
This one is created inside the `Player` constructor. It is created only once per player
instance so it is not a performance issue, but it is inconsistent with the "create fonts
once in main()" pattern that is explicitly commented in `main.py`.

**8. [game_npc.py] — State mutation (`dialogue_ticks -= 1`) happens inside `draw()`, not `update()`**

In `Villager.draw()`:
```python
if self.dialogue_ticks > 0:
    self._draw_bubble(screen, font, self.hint_text)
    self.dialogue_ticks -= 1   # <-- state change inside a draw method!
```

By convention, `draw()` should only read state and put pixels on screen. Changing state
inside `draw()` breaks this contract. If `draw()` were called more than once per frame (for
example to render a minimap), the timer would decrement twice as fast. It also makes the
code harder to read: a young developer looking for "where does the timer count down?" would
check `update()` first and not find it there.

**Suggested fix:** Move `self.dialogue_ticks -= 1` into `Villager.update()`.

**9. [game_world.py] — `get_solid_tiles()` rebuilds the wall rect list every call from scratch**

```python
def get_solid_tiles(self) -> list:
    wall_rects = []
    for row_index in range(MAP_ROWS):       # 22 rows
        for col_index in range(MAP_COLS):   # 40 columns = 880 iterations
            if MAP_GRID[row_index][col_index] == TILE_WALL:
                wall_rects.append(...)
    return wall_rects
```

The map is static (it never changes at runtime), so this always returns the same list.
In the current code `get_solid_tiles()` is not called in any loop, so it is not causing
a performance problem. But if it were ever called during the update loop, it would do 880
iterations every frame for no reason.

**Suggested fix:** Compute the list once in `World.__init__()` and store it as
`self.solid_tiles`, then `get_solid_tiles()` just returns `self.solid_tiles`.

**10. [game_items.py] — Placeholder frames list shares one Surface object for all entries**

In `_load_animated_sheet()`:
```python
return [placeholder] * frame_count
```

This creates a list where every entry is a reference to the **same** `pygame.Surface`.
If any code ever modifies a frame in place (e.g. draws onto it), all frames change at once.

**Suggested fix:**
```python
return [placeholder.copy() for _ in range(frame_count)]
```

---

## What's Good

- **`ASSET_ROOT = Path("assets")`** is a relative path in every file (world.py, enemies.py,
  items.py, npc.py). No `__file__`-relative paths. This is required for pygbag and is done
  correctly in all files.

- **`SHARD_POSITIONS`, `HEALTH_POTION_POSITIONS`, `ENEMY_SPAWN_POINTS`, `NPC_SPAWN_POINTS`**
  are all defined as module-level constants in `world.py` and imported correctly in `main.py`.

- **`just_died` design concept is right.** Setting a one-frame flag on death so `main.py`
  can react to it is a clean design. Only the reset placement needs fixing (HIGH issue 1).

- **`handle_input()` resets `self.attacking = False` at the start of every frame.**
  `handle_attack()` sets it `True` only on a KEYDOWN event. This means the flag is
  reliably True for exactly one frame per key-press — correct.

- **`get_attack_rect()` correctly returns a `pygame.Rect`** centered on the player,
  extending `ATTACK_RANGE_PX` in all directions. The comment "like swinging a sword in a
  circle" is perfect for a young reader.

- **No circular imports.** `world.py`, `enemies.py`, `items.py`, and `npc.py` are all
  independent of each other. `main.py` imports from all four. `player.py` only imports
  from `game.assets`. Clean dependency graph.

- **Draw order is correct:** world tiles → items → villagers → enemies → companions →
  player → HUD → shard counter → ESC hint → pause overlay. Matches the spec exactly.

- **`run_story_intro()` uses `await asyncio.sleep(0)` inside the while loop** — required
  for pygbag browser compatibility. Correct.

- **`npc_font` created once in `main()` and passed to `villager.draw(screen, npc_font)`** —
  the font is never created inside a draw function. Correct.

- **Space bar attack fires only when the game is not paused.** The `elif event.key ==
  pygame.K_SPACE` branch is in the `elif` chain after `elif game_paused:`, so it only
  executes when unpaused. Correct and correctly documented in the code comments.

- **`villager.draw(screen, npc_font)`** (font passed as argument) and
  **`companion.draw(screen)`** (no font argument) both match their method signatures
  in `npc.py`. No API mismatch.

- **`enemy.update(player)`** called with exactly one argument — matches `Enemy.update(self, player)`.

- **`item.check_collection(player)` return value is checked** and the item is removed
  from `item_list` when True. List is iterated as `item_list[:]` (a copy) when removing
  items during the loop — correct pattern.

- **`player.handle_attack(event)` called from the KEYDOWN handler** — not from the
  `keys_pressed` polling loop. This is important: KEYDOWN fires once per key-press,
  `keys_pressed` would fire every frame the key is held. The design is correct.

- **`import math` at the top of every file that uses it** (`enemies.py`, `items.py`,
  `npc.py`). Not inside any method bodies.

- **`pygame.display.flip()`** (not `.update()`) called in all loops. Correct.

- **`clock.tick(TARGET_FPS)` and `await asyncio.sleep(0)`** present in every loop
  iteration — including the new `run_story_intro()` loop.

- **`convert_alpha()` called on all loaded PNGs** throughout all files.

- **`pygame.Surface` with `SRCALPHA`** used correctly for transparent overlays and
  placeholder sprites throughout.

- **Sprite sheet slicing** (`_load_animated_sheet`) uses the same pattern as `game/assets.py`
  (`_slice_sheet`) — consistent across the codebase.

- **Fallback placeholder pattern** (solid colored rect with dark outline) used consistently
  in every file. The game will run without any art files.

- **`ATTACK_DAMAGE`** is a named constant in `player.py` — not a magic number baked into
  the hit-detection code. The import placement needs fixing (HIGH issue 2), but the
  constant itself is correctly defined and used.

- **Comments are excellent throughout.** Explanations like "counts up every game tick;
  when it reaches PORTAL_FRAME_SPEED we move to the next portal picture", "Think of it
  like swinging a sword in a circle around them!", and "Use item_list[:] (a copy) so we
  can safely remove items while looping" are exactly right for an 8-year-old collaborator.

---

## Kid-Readability Score: 9/10

The writing across all six files is warm, clear, and genuinely fun. Docstrings explain
the WHY behind every design choice, not just the WHAT. The use of named constants
throughout makes it easy to understand what numbers mean. The one point deducted is for:
(a) the inline import inside the loop (HIGH issue 2) which a young reader scanning the top
of `main.py` would not find, and (b) the state change hiding inside `draw()` (LOW issue 8)
which breaks the pattern a young reader would learn from the rest of the codebase.

---

## Verdict

Ready to apply to game/? **NO — fix the 3 HIGH issues first, then YES.**

### Summary of required fixes before applying:

1. **`enemies.py` — `just_died` reset:** Move `self.just_died = False` to the very first
   line of `Enemy.update()`, before the `STATE_DEAD` check. This is the most critical fix.
   The current code spawns hundreds of shards per enemy death.

2. **`main.py` — inline import:** Move `from game.player import ATTACK_DAMAGE` to the
   top-level import block as `from game.player import Player, ATTACK_DAMAGE`.

3. **`main.py` — surfaces in `draw_pause_overlay()`:** Create `dim_surface` and
   `panel_surface` once in `main()` and pass them into `draw_pause_overlay()` rather than
   allocating new surfaces every frame.

All three fixes are small (one-to-five line changes each). After those are applied,
the code is ready to be written to `game/world.py`, `game/enemies.py`, `game/items.py`,
`game/npc.py`, `game/player.py`, and `main.py`.
