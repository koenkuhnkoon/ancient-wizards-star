# The Ancient Wizard's Star — Story & Design Bible

---

## World Lore

Long ago, in a world called **Lumoria**, magic was everywhere. The rivers sparkled with light. The mountains hummed ancient songs. Every rock, tree, and cloud had a tiny bit of magic living inside it.

At the center of Lumoria floated a giant glowing star — the **Ancient Wizard's Star**. It was made by the very first wizards who ever lived. They poured all their love and power into it. The Star kept Lumoria safe. It gave energy to every living thing and kept the darkness away.

But one day, a terrible villain came. His name was **Voltrak**, the ninja land-eel. He wanted to steal the Star's power for himself. He cracked open the **Ancient Dimensional Portal Gate** — a magical doorway between worlds — and sent monsters pouring through it. Now Lumoria is in danger! Evil creatures roam the land. The Star is flickering. Only one hero can collect the magical shards, wake up the Ancient Portal Gate, and stop Voltrak before Lumoria goes dark forever. That hero... is YOU.

**Fun Fact:** The name "Lumoria" comes from the word *lumen*, which means light in Latin. Koen can tell his friends that the whole world is named after light!

---

## Playable Characters

### Wizard

The Wizard learned magic from old glowing books hidden deep in the Lumoria libraries. She can shoot powerful bolts of arcane energy and cast shields made of pure starlight. Her special power is the **Star Burst** — she calls down a tiny meteor from the sky to smash enemies! She is a little slow on her feet, but her spells hit hard from far away. Her dream is to find the original spellbooks written by the first wizards.

### Knight

The Knight has the toughest armor in all of Lumoria. He trained for years in the royal castle, learning how to block every kind of attack. His special power is the **Shield Slam** — he charges forward and bashes enemies with his giant shield, sending them flying! He has the most health of any character. He is brave, loyal, and a little bit clumsy — but in a funny way.

### Assassin

The Assassin moves like a shadow. No one hears her coming. She trained in the rooftops of Lumoria's great city, learning to leap, dodge, and strike in the blink of an eye. Her special power is the **Shadow Flash** — she vanishes and reappears right behind an enemy for a surprise attack! She is very fast but has less health, so she needs to be sneaky and smart.

### Miner

The Miner might look ordinary, but he knows every secret tunnel in Lumoria. He digs through mountains every day looking for magical crystals. His special power is the **Rock Blast** — he pulls a chunk of magical rock from the ground and hurls it at enemies like a cannonball! He can also move heavy objects that other characters cannot budge. He always has snacks in his pockets.

### Ninja

The Ninja is lightning fast and super cool. She studied at the top-secret Lumoria Ninja Academy, hidden behind a waterfall. Her special power is the **Star Shuriken** — she throws five glowing shurikens at once that bounce off walls! She can run faster than anyone else in the game. She loves telling riddles and always lands on her feet.

### Robot

The Robot was built by an ancient wizard hundreds of years ago and just woke up from a long nap. He does not fully understand magic, but he is incredibly strong and runs on star energy. His special power is the **Power Surge** — he charges up and releases a burst of electricity from his fists! He asks a lot of funny questions, like "Why do humans eat?" He is learning to be a hero one step at a time.

**Fun Fact:** Knights in real history wore armor that weighed as much as a full-grown dog — about 15 to 25 kilograms! Imagine running around in that!

---

## Monsters

### Evil Ninjas

Evil ninjas once trained at the same academy as the good ninja — but they chose the wrong path. Now they work for Voltrak. They sneak through tall grass and dark alleys, throwing poisoned darts and trying to trip heroes with their ropes. They are sneaky but not very strong on their own, so they like to attack in groups. Watch out for the one wearing the red headband — she is the trickiest.

### Sewage Creatures

Deep under Lumoria's cities live the sewage creatures. They are big, slimy, and smell absolutely terrible. They were once ordinary fish, but magical pollution turned them into grumpy monsters. They spit globs of slime that slow you down if you get hit. They live in underground tunnels and swamps. Bring a nose peg.

### Zombies

These zombies are not spooky — they are just very confused. They used to be Lumorian farmers and bakers before Voltrak's dark magic woke them up. Now they wander around moaning and bumping into things. They do not move fast, but there are a LOT of them. They drop bread crumbs sometimes instead of shards, which is a bit embarrassing for everyone.

### Land Octopus

The land octopus evolved over thousands of years to walk on land using its tentacles like legs. It can spin three of its tentacles at the same time to sweep enemies off their feet. It lives near rivers and muddy fields. Its suction cups can grab weapons right out of your hand, so keep moving! Despite all this, it is actually very ticklish.

### Little Devils

Little devils are only knee-high, but they are full of mischief. They zoom around on tiny flaming wings and throw fireballs the size of oranges. They giggle when they miss and get grumpy when they get hit. They live in warm, sunny fields and hang around volcano caves. They are hard to hit because they never stop moving.

### Skeletons

Skeletons are the oldest monsters in Lumoria. They have been guarding old ruins and treasure vaults for centuries. They carry rusty swords and cracked shields. They are medium-tough — not the hardest enemy, but they rattle and clank loudly, so at least you can hear them coming. Sometimes their heads fall off and keep rolling around, which can be a little silly.

### Poisonous Mushrooms

Poisonous mushrooms do not walk — they jump! They bounce along in patches, bumping into heroes and releasing puffs of purple spore clouds. If you breathe in the spores, your character moves slower for a few seconds. They grow in the deep forest and damp caves. They look pretty from far away with their bright red and purple caps, but do not get too close!

### Stonehead Turtles

Stonehead turtles are ancient creatures with shells made of solid rock. They are very slow but almost impossible to hurt from the front. Heroes need to get behind them or wait for them to pull their heads in before striking. They live near cliffs and rocky hills. When threatened, they curl into a ball and roll downhill — so stand aside! They have lived for over 500 years each and have seen everything.

**Fun Fact:** Real octopuses have three hearts! Two hearts pump blood to their gills, and one pumps it to the rest of their body. The land octopus in the game has four hearts — one extra for bravery.

---

## Bosses

### The Two Helper-Bosses

Before the player can face the main villain, they must defeat two powerful helpers who guard the path to the Ancient Dimensional Portal Gate.

#### Helper-Boss 1: Grimrak the Stone Golem

Grimrak is a giant made entirely of stolen magical rocks from the Lumorian mountains. Voltrak built him to be an unbreakable wall. He stomps the ground to create shockwaves and throws boulders across the field. His weak spot is the glowing crack in his chest — that is where Voltrak jammed in a shard of the Ancient Wizard's Star to bring him to life. Hit it enough times and Grimrak crumbles! He is slow but huge — the whole screen shakes when he walks.

#### Helper-Boss 2: Zara the Storm Witch

Zara used to be a good weather wizard. But Voltrak tricked her into thinking the heroes were the real villains. She can summon lightning storms, throw whirlwinds, and disappear into clouds. She fights from the air, so jumping and ranged attacks are key. If the player defeats her fairly, she realizes she was tricked — and at the end, she joins the good side and cheers you on. A mystery: she says she has met Voltrak before, long ago, when they were both young...

### The Final Boss: Voltrak the Ninja Land-Eel

**Name:** Voltrak, the Shockblade Eel

**Backstory:** Voltrak was once a small electric eel swimming in Lumoria's deepest river. He was curious and clever. One day he found a crack in the riverbed and slipped through — right into the space between worlds. There he discovered the Ancient Dimensional Portal Gate, half-buried in the dark. He spent a thousand years learning how to use it. He taught himself to walk on land, to hold a sword, to wear a ninja's cloak. He grew enormous. And he grew angry. He wanted what the Lumorian wizards had — a world filled with light and power — and he decided to take it.

Now Voltrak stands at the Gate. His body crackles with electricity. His sword — called **Thunderfang** — shoots bolts of lightning with every swing. He moves fast for something so long and slithery. He has two phases: in the first phase he fights on the ground, slithering in zigzag patterns and slashing with Thunderfang. In the second phase, when he is half-defeated, he rises up tall and calls lightning down from the sky while circling the arena. His weak point is the glowing blue star-mark on his neck — the shard of the Ancient Wizard's Star he swallowed long ago to gain his power.

When he is finally defeated, the stolen shard flies out of him, the Ancient Dimensional Portal Gate seals shut, and every stolen piece of the Ancient Wizard's Star snaps back together high in the sky. Lumoria is saved!

**Fun Fact:** Electric eels are not actually eels — they are a kind of knifefish! And they can produce up to 600 volts of electricity. That is enough to stun a horse. Voltrak produces about a million volts, which is a lot more, but luckily he is fictional.

---

## NPC Dialogues

### Friendly Villagers

1. "Hello, traveler! Be careful near the eastern swamp — those sewage creatures have been extra grumpy since yesterday. One of them knocked over my vegetable cart!"

2. "My grandmother used to tell me about the Ancient Wizard's Star. She said it smells like fresh rain and warm bread. I hope you can fix it!"

3. "Have you seen my chicken? She keeps running toward the monster camps. I think she is braver than me, honestly."

4. "If you find any blue mushrooms on your travels — NOT the purple ones, those are dangerous — bring them back! I make a great soup. I will give you something nice in return."

5. "I used to think heroes only existed in stories. Then you showed up. Please do not get hurt. We are all rooting for you!"

### Shopkeepers

1. "Welcome, welcome! I have got swords, shields, and a very nice hat that once belonged to a duke. The hat does not do anything special, but it looks amazing. Five shards."

2. "You look like someone who appreciates quality armor. This breastplate is made from stonehead turtle shell — the turtle donated it voluntarily, I promise. Well, sort of."

3. "Magical shards are my favorite currency. Coins rust. Shards glow! What can I get you today? I just got in a fresh batch of speed boots."

4. "I will be honest with you — I do not know exactly what this purple potion does. But it sparkles nicely and the last person who drank it could jump twice as high. Probably. Maybe. Eight shards."

5. "Heroes get a discount! Well, a tiny discount. One shard off everything. I am not made of money. But I do believe in you, which is worth a lot."

### Companion Characters

1. "I have been fighting monsters my whole life, but I have never had a partner like you. Together we cannot lose. Let us go!"

2. "Do you hear that rumbling? That is Grimrak warming up. Good — it means he has not spotted us yet. Follow my lead and we will surprise him."

3. "When I was small, I was scared of everything. Then I realized: the monsters are scared too — they are scared of US. So let us show them why!"

4. "I will cover your left side if you cover my right. That is the deal. Also, if you find extra bread, I get half. Those are my two rules."

5. "The star is counting on us. I can feel it — can you? That warm tingly feeling in your chest? That is the Ancient Wizard's Star saying thank you in advance. Let us not let it down."

**Fun Fact:** In many old video games, shopkeeper characters had some of the most famous and funny dialogue lines ever written. Players remembered them for years! Koen can write his own shopkeeper lines too — there is no wrong answer.

---

## Quest Hooks

### The Boss Area: The Valley of the Cracked Gate

As the hero approaches the Ancient Dimensional Portal Gate for the first time, they find a small message carved into a mossy stone pillar at the valley entrance. It reads:

*"Only the one who carries three pure shards may open what was sealed. Only the one who was never afraid may walk through. — W.V."*

Who is W.V.? No one in the village knows. The companions look at each other nervously. Deep in the valley, behind Grimrak's rocky fortress and Zara's storm-tower, the Gate stands — cracked, flickering, humming with strange energy. But then the player discovers something no one expected: a small campfire still burning near the Gate. Someone was here recently. Someone has been waiting.

The mystery: the initials W.V. belong to a wizard named **Wela Voss** — Voltrak's very first teacher, from before he became a villain. She tried to stop him a thousand years ago and failed. She left the message for the hero who would come after her. And her journal, hidden beneath a loose stone near the campfire, tells the real story of how Voltrak first found the Gate — and hints at a secret weakness he does not even know he has.

### The Final Portal Area: The Shatterlight Arena

When Voltrak is defeated and the shard bursts free, the Ancient Dimensional Portal Gate does not just close — it does something no one predicted. It opens wide, fully, for just ten seconds. A blast of warm golden light pours out. And floating in that light is a figure: old, glowing, smiling.

It is one of the original ancient wizards who built the Star.

She cannot speak — she exists only as a memory of light. But she reaches out, and the Ancient Wizard's Star blazes brighter than ever before, sending beams of light across all of Lumoria. Every village lights up. Every river sparkles again. Every monster's power fades.

Then she is gone. The Gate closes.

But the hero finds one last thing on the ground where she stood: a tiny stone with the letters **W.V.** carved into it — and a small drawing of a smiling eel, from before it ever became a monster.

The surprise for Koen: Wela Voss and Voltrak were friends once. The ancient wizard who built the Star and the eel who wanted to steal it were both, long ago, just curious creatures who wanted to understand the world. The story is not just about fighting — it is about what happens when someone chooses fear and anger instead of friendship. And it is about the hero who made a different choice.

**Fun Fact:** Many famous fantasy stories — like The Lord of the Rings and The Legend of Zelda — hide little mysteries and secret messages in their worlds for players and readers to discover. Easter eggs! Koen can hide his own secret messages in the game world too.

---

*Story created by the Design Lead — reviewed by Koen and his dad!*
