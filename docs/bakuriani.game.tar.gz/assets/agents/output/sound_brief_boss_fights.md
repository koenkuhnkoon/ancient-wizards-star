# Sound Brief — Boss Fights, Monster Attacks & UI Events

**Game:** The Ancient Wizard's Star (Python/Pygame, top-down RPG)
**Style:** Cartoon action RPG — sounds should be punchy, satisfying, and fun.
  Think Brawl Stars: exaggerated, clear, and distinctive for each character type.

---

## Technical Specs

- **Format:** WAV or OGG
- **Sample rate:** 44 100 Hz
- **Bit depth:** 16-bit
- **Channels:** Mono or stereo
- **Drop location:** `assets/sounds/` folder
- **Length:** Keep sounds short and punchy — they loop or replay frequently

---

## 1. Monster Attack Sounds

Played each time a monster lands a hit on the player.
Each should be short (0.2–0.5 s), punchy, and clearly identify the monster type.

| File | Duration | Description |
|------|----------|-------------|
| `enemy_evil_ninja_attack.wav` | ~0.3 s | **Sharp sword swipe** — fast metallic whoosh. Think a blade slicing air quickly. Clean and crisp. |
| `enemy_skeleton_attack.wav` | ~0.4 s | **Dry bone clunk** — hollow wooden knock + rattle. Like two bones hitting together. |
| `enemy_zombie_attack.wav` | ~0.5 s | **Slow wet slap** — heavy damp thud with a low gurgling undertone. Slower attack = slower sound. |
| `enemy_sewage_creature_attack.wav` | ~0.4 s | **Slimy splat** — wet squelch, like something sticky hitting a wall. Moist and gross (in a fun way!). |
| `enemy_land_octopus_attack.wav` | ~0.4 s | **Rubbery thwack** — tentacle slap with a suction-cup pop at the end. Squishy and satisfying. |
| `enemy_little_devil_attack.wav` | ~0.3 s | **Tiny pitchfork zing** — high-pitched metallic scrape/ding. Small and sharp, like a miniature weapon. |
| `enemy_poisonous_mushroom_attack.wav` | ~0.4 s | **Soft toxic puff** — airy whoosh with a slight hiss at the end. Like a spore cloud being expelled. |
| `enemy_stonehead_turtle_attack.wav` | ~0.5 s | **Thunderous head-snap** — hard crack like a whip, followed by a stone click. Powerful and sudden. |

---

## 2. Boss Attack Sounds

### Grimrak the Stone Golem

| File | Duration | Description |
|------|----------|-------------|
| `boss_grimrak_attack.wav` | ~0.5 s | **Stone melee hit** — deep guttural grunt + heavy impact thud. Like a boulder punching. Low and massive. |
| `boss_grimrak_slam.wav` | ~0.8 s | **Ground slam** — the biggest sound. Deep stone BOOM on impact, then a rolling ground rumble that fades over ~0.5 s. Think earthquake impact. |

### Zara the Storm Witch

| File | Duration | Description |
|------|----------|-------------|
| `boss_zara_attack.wav` | ~0.4 s | **Staff charge** — magical crackle building up, like electricity charging before release. Mystical and sharp. |
| `boss_zara_bolt_fire.wav` | ~0.4 s | **Magic bolt launch** — whip-crack + purple sparkling swoosh. The bolt leaving Zara's hands. Mystical but fast. |
| `boss_zara_bolt_hit.wav` | ~0.3 s | **Bolt impact on player** — short electric zap. Satisfying sting sound, like static shock but louder. |

### Voltrak the Shockblade Eel

| File | Duration | Description |
|------|----------|-------------|
| `boss_voltrak_attack.wav` | ~0.4 s | **Electric sword slash** — sword whoosh layered with crackling electricity arc. Fast and dangerous. |
| `boss_voltrak_bolt.wav` | ~0.4 s | **Electric bolt projectile** — high-pitched crackling dart. Like a compressed lightning bolt launching. Sharp and zappy. |
| `boss_voltrak_shockwave.wav` | ~1.0 s | **Shockwave ring** — begins as a deep electric hum/throb, then bursts into a sharp electric crack at the peak, then fades. Feels like a radial pulse. |
| `boss_voltrak_intro.wav` | ~1.5 s | **Voltrak's entrance** — a building electric crackle rising in pitch and intensity, then BOOM — a thunder crash. Signals the final boss has arrived. |

---

## 3. UI & Event Sounds

| File | Duration | Description |
|------|----------|-------------|
| `portal_enter.wav` | ~1.2 s | **Entering the portal** — a magical dimensional whoosh. Like a tear in space opening up. Echoing, mysterious, slightly unsettling. |
| `companion_summon.wav` | ~0.6 s | **Companion appears** — heroic bright chime + sparkle burst. Feels like a helpful ally arriving to save the day. Uplifting and warm. |
| `victory_fanfare.wav` | ~3.0 s | **Victory! Lumoria is saved!** — a short triumphant fanfare. Brass instrument stabs (da-da-da-DA!), then an ascending melody ending on a held high note. Full of joy and celebration. Think a mini-version of a classic game win jingle. |

---

## Tone Reference

- **Regular monsters:** Fun, cartoony, exaggerated — safe for an 8-year-old
- **Mini-bosses (Grimrak/Zara):** More dramatic, but still clearly game-like
- **Voltrak:** Epic and electric — the final boss should feel genuinely threatening
- **Victory fanfare:** Pure celebration — the player just saved the world!

## Delivery Checklist — 18 Files Total

```
assets/sounds/
  # Monster attacks (8 files)
  enemy_evil_ninja_attack.wav
  enemy_skeleton_attack.wav
  enemy_zombie_attack.wav
  enemy_sewage_creature_attack.wav
  enemy_land_octopus_attack.wav
  enemy_little_devil_attack.wav
  enemy_poisonous_mushroom_attack.wav
  enemy_stonehead_turtle_attack.wav

  # Boss attacks (8 files)
  boss_grimrak_attack.wav
  boss_grimrak_slam.wav
  boss_zara_attack.wav
  boss_zara_bolt_fire.wav
  boss_zara_bolt_hit.wav
  boss_voltrak_attack.wav
  boss_voltrak_bolt.wav
  boss_voltrak_shockwave.wav
  boss_voltrak_intro.wav

  # UI events (3 files)
  portal_enter.wav
  companion_summon.wav
  victory_fanfare.wav
```
